﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AssetManagement.Model
{
    public class GetAssetTypeCount
    {
        public string Asset_Type { get; set; }
        public int count { get; set; } = 0;
    }
}
