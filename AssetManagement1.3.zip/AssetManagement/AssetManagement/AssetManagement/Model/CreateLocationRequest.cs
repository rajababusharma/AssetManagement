﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AssetManagement.Model
{
    public class CreateLocationRequest
    {
        public string Company_Id { get; set; }
        public string Location_Description { get; set; }
    }
}
