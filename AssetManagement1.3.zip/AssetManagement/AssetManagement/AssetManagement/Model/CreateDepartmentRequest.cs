﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AssetManagement.Model
{
    public class CreateDepartmentRequest
    {
        public string Company_Id { get; set; }
        public string Department { get; set; }
    }
}
