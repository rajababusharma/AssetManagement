﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AssetManagement.Model
{
    public class PostResponseForAll
    {
        public string Status { get; set; }
        public string Msg { get; set; }
    }
}
