﻿using AssetManagementAPI.BLL;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AssetManagementAPI.Controllers
{
    public class GetImagesController : ApiController
    {
        [HttpGet]
        public HttpResponseMessage GetImages(string AssetId)
        {
            Asset_ImagesBLL bll = new Asset_ImagesBLL();
            AssetsImagesResponse response = new AssetsImagesResponse();

            response = bll.GetAssetImageList(AssetId);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }
    }
}
