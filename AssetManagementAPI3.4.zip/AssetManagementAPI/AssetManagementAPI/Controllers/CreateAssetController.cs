﻿using AssetManagementAPI.BLL;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace AssetManagementAPI.Controllers
{
    public class CreateAssetController : ApiController
    {
        CreateAssetsBLL bll;
        [HttpPost]
        public HttpResponseMessage CreateAssets(CreateAssetRequest request)
        {

            bll = new CreateAssetsBLL();
            PostResponse response = new PostResponse();

            response = bll.CreateAssets(request);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }

        [HttpGet]
        public HttpResponseMessage GetAssets(string assetid,string branch)
        {
            bll = new CreateAssetsBLL();

            Asset_InfoResponse response = new Asset_InfoResponse();

            response = bll.GetStocks(assetid,branch);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }

        [HttpGet]
        public HttpResponseMessage GetAssets(string branch)
        {
            bll = new CreateAssetsBLL();

            AssetDataResponse response = new AssetDataResponse();

            response = bll.GetStocks(branch);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }
    }
}