﻿using AssetManagementAPI.BLL;
using AssetManagementAPI.Models;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AssetManagementAPI.Controllers
{
    public class MoveController : ApiController
    {
        [HttpGet]
        public HttpResponseMessage GetMoveData(string Branch)
        {
            GetAssetMoveDetailsBLL BLL = new GetAssetMoveDetailsBLL();
            AssetMoveDetailResponse response = new AssetMoveDetailResponse();

            response = BLL.GetAssetMoveDataList(Branch);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }

        [HttpGet]
        public HttpResponseMessage GetMoveNotifications(string ToBranch)
        {
            GetAssetMoveDetailsBLL BLL = new GetAssetMoveDetailsBLL();
            AssetMoveDetailResponse response = new AssetMoveDetailResponse();

            response = BLL.GetMoveNotifications(ToBranch);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }


        [HttpPost]
        public HttpResponseMessage POST_MoveAsset([FromBody] POST_MoveAssetDataRequest request)
        {
            PostMoveAssetBLL BLL = new PostMoveAssetBLL();
            PostResponse response = new PostResponse();
            response = BLL.PostStockTally(request);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }

        [HttpGet]
        public HttpResponseMessage UpdateMoveAsset(string AssetId, string ToBranch,string ToLocation)
        {
            PostMoveAssetBLL BLL = new PostMoveAssetBLL();
            PostResponse response = new PostResponse();

            response = BLL.UpdateMoveAsset(AssetId,ToBranch, ToLocation);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }
    }
}