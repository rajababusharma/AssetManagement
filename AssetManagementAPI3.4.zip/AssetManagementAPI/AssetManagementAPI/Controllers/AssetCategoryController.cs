﻿using AssetManagementAPI.BLL;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AssetManagementAPI.Controllers
{
    public class AssetCategoryController : ApiController
    {
        AssetCategoryCountBLL dashboardBLL;
        // GET api/<controller>


        [HttpGet]
        public HttpResponseMessage GetAssetCategoryCount(string Branch)
        {
            dashboardBLL = new AssetCategoryCountBLL();
            AssetCategoryCountResp response = new AssetCategoryCountResp();

            response = dashboardBLL.GetStockTally(Branch);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }
    }
}