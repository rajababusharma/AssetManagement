﻿using AssetManagementAPI.BLL;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AssetManagementAPI.Controllers
{
    public class ValuesController : ApiController
    {
        GetStockTallyBLL stocktallybll;
       

        [HttpGet]
        public HttpResponseMessage GetStockData(string Branch)
        {
            stocktallybll = new GetStockTallyBLL();
            StockTallyGetResponse response = new StockTallyGetResponse();

            response = stocktallybll.GetStockTally(Branch);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }

        [HttpPost]
        public HttpResponseMessage PostStockTallyData([FromBody] List<STockTallyDetails> STockTallyDetails)
        {
            stocktallybll = new GetStockTallyBLL();
            PostResponse response = new PostResponse();

            response = stocktallybll.PostStockTally(STockTallyDetails);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }
    }
}
