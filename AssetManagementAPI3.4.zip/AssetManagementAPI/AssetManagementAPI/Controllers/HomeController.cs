﻿using AssetManagementAPI.BLL;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace AssetManagementAPI.Controllers
{
    public class HomeController : ApiController
    {
       
        LoginBLL loginbll;
      
        [HttpGet]
        public HttpResponseMessage Login(string username, string password)
        {
            loginbll = new LoginBLL();
            LoginResponse response = new LoginResponse();

            response = loginbll.UserLogin(username, password);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }


       
        [HttpGet]
        public string hello()
        {
            return "hello world";
        }

    }
}
