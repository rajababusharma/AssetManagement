﻿using AssetManagementAPI.BLL;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AssetManagementAPI.Controllers
{
    public class GetCat_Sub_Dept_VendorController : ApiController
    {
        GetCat_SubCat_Dept_VenorBLL BLL;
        // GET api/<controller>


        [HttpGet]
        public HttpResponseMessage GetCat_Sub_Dept_Vendor()
        {
            BLL = new GetCat_SubCat_Dept_VenorBLL();
            Cate_Sub_Dept_VendorResp response = new Cate_Sub_Dept_VendorResp();

            response = BLL.GetCat_Sub_Dept_Vendor();


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }

        [HttpPost]
        public HttpResponseMessage InsertCategory(CreateCategoryRequest request)
        {
            BLL = new GetCat_SubCat_Dept_VenorBLL();
            PostResponse response = new PostResponse();

            response = BLL.InsertCategory(request);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }

      
    }
}
