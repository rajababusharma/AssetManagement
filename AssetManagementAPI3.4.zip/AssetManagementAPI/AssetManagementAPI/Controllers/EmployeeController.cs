﻿using AssetManagementAPI.BLL;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace AssetManagementAPI.Controllers
{
    public class EmployeeController : ApiController
    {
        EmployeeMasterBLL bll;
        // GET api/<controller>

        [HttpGet]
        public HttpResponseMessage GetEmployeeList(string Branch)
        {
            bll = new EmployeeMasterBLL();
            EmployeeMasterResp response = new EmployeeMasterResp();

            response = bll.GetEmployee(Branch);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }

        [HttpPost]
        public HttpResponseMessage PostEmployee(CreateEmployeeRequest request)
        {
            bll = new EmployeeMasterBLL();
            PostResponse response = new PostResponse();

            response = bll.InsertEmployee(request);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }
    }
}