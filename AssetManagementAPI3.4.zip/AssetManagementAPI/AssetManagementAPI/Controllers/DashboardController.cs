﻿using AssetManagementAPI.BLL;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AssetManagementAPI.Controllers
{
    public class DashboardController : ApiController
    {
        // GET api/<controller>
        DashboardBLL dashboardBLL;
       
        [HttpGet]
        public HttpResponseMessage GetBranchWiseAssetCount()
        {
            dashboardBLL = new DashboardBLL();
            BranchWiseAssetCount response = new BranchWiseAssetCount();

            response = dashboardBLL.GetBranchWiseAssetCount();


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }


    }
}