﻿using AssetManagementAPI.BLL;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AssetManagementAPI.Controllers
{
    public class LocationController : ApiController
    {

        LocationMasterBLL LocationMasterBLL;
        // GET api/<controller>

        [HttpGet]
        public HttpResponseMessage GetLocationList()
        {
            LocationMasterBLL = new LocationMasterBLL();
            LocationMasterResp response = new LocationMasterResp();

            response = LocationMasterBLL.GetALLLocations();


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }

        [HttpPost]
        public HttpResponseMessage InsertLocation(CreateLocationRequest request)
        {
            LocationMasterBLL = new LocationMasterBLL();
            PostResponse response = new PostResponse();

            response = LocationMasterBLL.CreateLocations(request);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }
        
    }
}