﻿using AssetManagementAPI.BLL;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AssetManagementAPI.Controllers
{
    public class TransferController : ApiController
    {
        [HttpPost]
        public HttpResponseMessage InsertIntoDisposed(PostAssetTransferRequest request)
        {
            InsertIntoTransferBLL BLL = new InsertIntoTransferBLL();
            PostResponse response = new PostResponse();

            response = BLL.InsertIntoTransfer(request);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }
    }
}