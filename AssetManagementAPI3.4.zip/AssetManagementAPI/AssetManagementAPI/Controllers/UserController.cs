﻿using AssetManagementAPI.BLL;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace AssetManagementAPI.Controllers
{
    public class UserController : ApiController
    {
        GetUsersListBLL bll;
        // GET api/<controller>

        [HttpGet]
        public HttpResponseMessage GetUserList()
        {
            bll = new GetUsersListBLL();
            UserMasterResp response = new UserMasterResp();

            response = bll.GetUserList();


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }

        [HttpGet]
        public HttpResponseMessage GetUsersRight(string user)
        {
            bll = new GetUsersListBLL();
            UserRightsResp response = new UserRightsResp();

            response = bll.GetUsersRight(user);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }

        [HttpPost]
        public HttpResponseMessage InsertIntoUserRights(PostUsersRightRequest request)
        {

            bll = new GetUsersListBLL();
            PostResponse response = new PostResponse();

            response = bll.InsertIntoUserRights(request);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }

       
    }
}