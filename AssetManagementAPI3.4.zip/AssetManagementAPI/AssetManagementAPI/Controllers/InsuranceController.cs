﻿using AssetManagementAPI.BLL;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AssetManagementAPI.Controllers
{
    public class InsuranceController : ApiController
    {
        InsuranceReportBLL BLL;
        [HttpGet]
        public HttpResponseMessage GetAssetInsuranceList()
        {
            BLL = new InsuranceReportBLL();
            InsuranceDetailResponse response = new InsuranceDetailResponse();

            response = BLL.GetAssetInsuranceList();


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }

        [HttpPost]

        public HttpResponseMessage CreateInsurance(InsuranceList request)
        {
            CreateAMCBLL BLL = new CreateAMCBLL();
            // AMCDetailsResponse response = new AMCDetailsResponse();
            PostResponse response = new PostResponse();
            response = BLL.CreateInsurance(request);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }
    }
}