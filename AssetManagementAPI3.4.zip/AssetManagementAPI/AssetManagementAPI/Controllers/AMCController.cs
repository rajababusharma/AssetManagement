﻿using AssetManagementAPI.BLL;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AssetManagementAPI.Controllers
{
    public class AMCController : ApiController
    {
        DashboardBLL dashboardBLL;
        // GET api/<controller>

       
        [HttpGet]
        public HttpResponseMessage GetAMCRepair(string Branch)
        {
            dashboardBLL = new DashboardBLL();
            GetAMC_RepairCount response = new GetAMC_RepairCount();

            response = dashboardBLL.Get_CountAMC(Branch);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }


        [HttpGet]
        public HttpResponseMessage GetAMCData()
        {
            AMCDetailsBLL dashboardBLL = new AMCDetailsBLL();
            AMCDetailsResponse response = new AMCDetailsResponse();

            response = dashboardBLL.GetAssetAMCList();


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }

        [HttpPost]

        public HttpResponseMessage CreateAMC(AMCList request)
        {
            CreateAMCBLL BLL = new CreateAMCBLL();
            // AMCDetailsResponse response = new AMCDetailsResponse();
            PostResponse response = new PostResponse();
            response = BLL.CreateAMC(request);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }
    }
}