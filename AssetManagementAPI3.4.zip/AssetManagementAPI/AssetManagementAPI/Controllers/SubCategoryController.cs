﻿using AssetManagementAPI.BLL;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AssetManagementAPI.Controllers
{
    public class SubCategoryController : ApiController
    {
        [HttpPost]
        public HttpResponseMessage InsertSubCategory(CreateSubCategoryRequest request)
        {
            GetCat_SubCat_Dept_VenorBLL BLL = new GetCat_SubCat_Dept_VenorBLL();
            PostResponse response = new PostResponse();

            response = BLL.InsertSubCategory(request);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }
    }
}
