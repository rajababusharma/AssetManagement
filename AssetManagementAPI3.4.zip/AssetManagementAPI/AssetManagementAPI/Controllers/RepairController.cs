﻿using AssetManagementAPI.BLL;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AssetManagementAPI.Controllers
{
    public class RepairController : ApiController
    {
        RepairReportBLL BLL;
        InsertIntoRepairAssetBLL ReportBLL;
        [HttpGet]
        public HttpResponseMessage GetAssetRepairData()
        {
            BLL = new RepairReportBLL();
            AssetRepairResponse response = new AssetRepairResponse();

            response = BLL.GetAssetRepairList();


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }

        [HttpGet]
        public HttpResponseMessage IsAssetReturned(string AssetId)
        {
            RepairReportBLL BLL = new RepairReportBLL();
            PostResponse response = new PostResponse();

            response = BLL.UpdateIsReturned(AssetId);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }

        [HttpPost]
        public HttpResponseMessage InsertIntoRepair(PostAssetRepairRequest request)
        {
           
            InsertIntoRepairAssetBLL BLL = new InsertIntoRepairAssetBLL();
            PostResponse response = new PostResponse();

            response = BLL.InsertIntoRepair(request);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }
    }
}