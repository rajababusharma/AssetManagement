﻿using AssetManagementAPI.BLL;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AssetManagementAPI.Controllers
{
    public class DepartmentController : ApiController
    {
        [HttpPost]

        public HttpResponseMessage CreateDepartment(CreateDepartmentRequest request)
        {
            DepartmentBLL BLL = new DepartmentBLL();
            PostResponse response = new PostResponse();
            response = BLL.CreateDepartment(request);
            return Request.CreateResponse(HttpStatusCode.OK, response);
        }
    }
}
