﻿using AssetManagementAPI.BLL;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AssetManagementAPI.Controllers
{
    public class DisposedController : ApiController
    {
        [HttpGet]
        public HttpResponseMessage GetDisposedData(string Branch)
        {
            DisposalReportBLL BLL = new DisposalReportBLL();
            DisposeReportResponse response = new DisposeReportResponse();

            response = BLL.GetDisposalList(Branch);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }

        [HttpPost]
        public HttpResponseMessage InsertDisposed(PostDisposeAssetRequest request)
        {
            InsertIntoDisposeBLL BLL = new InsertIntoDisposeBLL();
            PostResponse response = new PostResponse();

            response = BLL.InsertIntoDispose(request);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }
    }
}