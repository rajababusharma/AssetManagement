﻿using AssetManagementAPI.BLL;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AssetManagementAPI.Controllers
{
    public class RecoverPasswordController : ApiController
    {
        RecoverPasswordBLL BLL;
        [HttpGet]
        public HttpResponseMessage GetPassword(string email)
        {
            BLL = new RecoverPasswordBLL();
            RecoverPasswordResp response = new RecoverPasswordResp();

            response = BLL.GetPasswordRecover(email);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }
    }
}
