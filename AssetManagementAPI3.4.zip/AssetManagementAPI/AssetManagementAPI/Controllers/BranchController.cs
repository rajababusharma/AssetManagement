﻿using AssetManagementAPI.BLL;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AssetManagementAPI.Controllers
{
    public class BranchController : ApiController
    {
        BranchMasterBLL BranchMasterBLL;
        // GET api/<controller>

        [HttpGet]
        public HttpResponseMessage Get()
        {
            BranchMasterBLL = new BranchMasterBLL();
            BranchMasterResp response = new BranchMasterResp();

            response = BranchMasterBLL.GetALLBranches();


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }

       [HttpPost]
       public HttpResponseMessage PostBranch(CreateBranchRequest request)
        {
            BranchMasterBLL = new BranchMasterBLL();
            PostResponse response = new PostResponse();

            response = BranchMasterBLL.InsertBranch(request);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }

       
    }
}