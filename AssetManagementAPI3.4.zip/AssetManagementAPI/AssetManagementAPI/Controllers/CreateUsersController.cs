﻿using AssetManagementAPI.BLL;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace AssetManagementAPI.Controllers
{
    public class CreateUsersController : ApiController
    {
        GetUsersListBLL bll;
        [HttpPost]
        public HttpResponseMessage CreateUsers(CreateUserRequest request)
        {

            bll = new GetUsersListBLL();
            PostResponse response = new PostResponse();

            response = bll.CreateUsers(request);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }
    }
}