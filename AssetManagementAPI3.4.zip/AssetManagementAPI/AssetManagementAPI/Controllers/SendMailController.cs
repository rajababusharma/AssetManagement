﻿using AssetManagementAPI.BLL;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace AssetManagementAPI.Controllers
{
    public class SendMailController : ApiController
    {
        [HttpGet]
        public HttpResponseMessage SendMail(string to, string pwd)
        {
            SendMailBLL BLL = new SendMailBLL();
            PostResponse response = new PostResponse();
            response = BLL.SendMail1(to,pwd);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }
    }
}
