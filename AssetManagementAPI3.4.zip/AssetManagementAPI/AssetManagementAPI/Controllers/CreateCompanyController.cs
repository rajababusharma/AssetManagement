﻿using AssetManagementAPI.BLL;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;
using System.Web.Mvc;

namespace AssetManagementAPI.Controllers
{
    public class CreateCompanyController : ApiController
    {
        CreateCompanyBLL bll;
        [System.Web.Http.HttpPost]
        public HttpResponseMessage CreateCompany(CreateCompanyRequest request)
        {

            bll = new CreateCompanyBLL();
            PostResponse response = new PostResponse();

            response = bll.CreateCompany(request);


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }

        [System.Web.Http.HttpGet]
        public HttpResponseMessage IsCompanyExist()
        {

            bll = new CreateCompanyBLL();
            PostResponse response = new PostResponse();

            response = bll.IsCompanyExist();


            return Request.CreateResponse(HttpStatusCode.OK, response);
        }
    }
}