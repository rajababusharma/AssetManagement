﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AssetManagementAPI.Models
{
    public class CreateDepartmentRequest
    {
        public string Company_Id { get; set; }
        public string Department { get; set; }
    }
}