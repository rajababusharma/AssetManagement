﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace AssetManagementAPI.Models
{
    public class CreateCategoryRequest
    {
        public string Company_Id { get; set; }
        public string Category_Description { get; set; }
    }
}