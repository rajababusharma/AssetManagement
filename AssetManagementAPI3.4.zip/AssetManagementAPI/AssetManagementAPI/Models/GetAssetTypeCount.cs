﻿namespace AssetManagementAPI.Models
{
    public class GetAssetTypeCount
    {
        public string Asset_Type { get; set; }
        public int count { get; set; } = 0;
    }
}