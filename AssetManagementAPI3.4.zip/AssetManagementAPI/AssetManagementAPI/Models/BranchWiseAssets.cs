﻿namespace AssetManagementAPI.Models
{
    public class BranchWiseAssets
    {
        public string Branch { get; set; }
        public int Asset_Count { get; set; } = 0;
    }
}