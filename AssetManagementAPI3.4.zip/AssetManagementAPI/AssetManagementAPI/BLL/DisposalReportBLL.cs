﻿using AssetManagementAPI.DatabaseHelper;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace AssetManagementAPI.BLL
{
    public class DisposalReportBLL
    {
        DBConnection con;
        public DisposeReportResponse GetDisposalList(string Branch)
        {
            DisposeReportResponse response = new DisposeReportResponse();
            DataSet ds = new DataSet();
            string st = "No record found";


            try
            {

                 SqlParameter prm1 = new SqlParameter("@Branch", Branch);


                using (con = new DBConnection())
                {
                     SqlParameter[] parameters = { prm1 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "GetAssetDisposalReport", parameters);
                }


                List<DisposalReportList> stockDetailslist = new List<DisposalReportList>();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                    {
                        DisposalReportList stockDetails = new DisposalReportList();
                        stockDetails.Company_Id = ds.Tables[0].Rows[i]["Company_Id"].ToString();
                        stockDetails.Asset_id = ds.Tables[0].Rows[i]["Asset_id"].ToString();
                        stockDetails.Asset_name = ds.Tables[0].Rows[i]["Asset_name"].ToString();
                        stockDetails.Description = ds.Tables[0].Rows[i]["Description"].ToString();
                        stockDetails.Location = ds.Tables[0].Rows[i]["Location"].ToString();
                        stockDetails.Branch = ds.Tables[0].Rows[i]["Branch"].ToString();
                        stockDetails.ReasonFor_Dispose = ds.Tables[0].Rows[i]["ReasonFor_Dispose"].ToString();
                        stockDetails.ModeOf_Disposal = ds.Tables[0].Rows[i]["ModeOf_Disposal"].ToString();
                        stockDetails.Residual_Value = ds.Tables[0].Rows[i]["Residual_Value"].ToString();
                        stockDetails.Authorized_By = ds.Tables[0].Rows[i]["Authorized_By"].ToString();
                        stockDetails.FinalLocation = ds.Tables[0].Rows[i]["FinalLocation"].ToString();
                        stockDetails.AssetDispose_Date = ds.Tables[0].Rows[i]["AssetDispose_Date"].ToString();

                        stockDetails.Image1 = ds.Tables[0].Rows[i]["Img1"].ToString();
                        stockDetails.Image2 = ds.Tables[0].Rows[i]["Img2"].ToString();
                        stockDetails.Image3 = ds.Tables[0].Rows[i]["Img3"].ToString();

                        stockDetailslist.Add(stockDetails);

                    }
                    response.DisposalReportList = stockDetailslist;
                    response.Msg = "Success";
                    response.Status = "true";

                }
                else
                {
                    response.Status = "false";
                    response.Msg = st;
                }
            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;

        }
    }
}