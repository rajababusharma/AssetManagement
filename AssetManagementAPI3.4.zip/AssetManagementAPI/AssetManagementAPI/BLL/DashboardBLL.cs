﻿using AssetManagementAPI.DatabaseHelper;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace AssetManagementAPI.BLL
{
    public class DashboardBLL
    {
        DBConnection con;
        public BranchWiseAssetCount GetBranchWiseAssetCount()
        {
            DataSet ds = new DataSet();
            string st = "No record found";

            BranchWiseAssetCount response = new BranchWiseAssetCount();
            try
            {

               // SqlParameter prm1 = new SqlParameter("@user_name", Branch);


                using (con = new DBConnection())
                {
                   // SqlParameter[] parameters = { prm1 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "GetBranchWiseAssetCount");
                }


                List<BranchWiseAssets> stockDetailslist = new List<BranchWiseAssets>();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                    {
                        BranchWiseAssets stockDetails = new BranchWiseAssets();
                        stockDetails.Branch = ds.Tables[0].Rows[i]["Branch"].ToString();
                        stockDetails.Asset_Count =Convert.ToInt32( ds.Tables[0].Rows[i]["Asset_Count"]);
                     
                        stockDetailslist.Add(stockDetails);

                    }
                    response.BranchWiseAssets = stockDetailslist;
                    response.Msg = "Success";
                    response.Status = "true";

                }
                else
                {
                    response.Status = "false";
                    response.Msg = st;
                }
            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }

        public GetAMC_RepairCount Get_CountAMC(string Branch)
        {
            DataSet ds = new DataSet();
            string st = "No record found";
            GetAMC_RepairCount response = new GetAMC_RepairCount();
            try
            {

                SqlParameter prm1 = new SqlParameter("@Branch", Branch);


                using (con = new DBConnection())
                {
                    SqlParameter[] parameters = { prm1 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "GetAMC_INSUCount", parameters);
                }


                if (ds.Tables[0].Rows.Count > 0 || ds.Tables[1].Rows.Count > 0 || ds.Tables[2].Rows.Count > 0 || ds.Tables[3].Rows.Count > 0 || ds.Tables[4].Rows.Count > 0)
                {

                    List<GetAssetTypeCount> assetlist = new List<GetAssetTypeCount>();
                    if (ds.Tables[0].Rows.Count > 0)
                    {
                        GetAssetTypeCount getAssettype = new GetAssetTypeCount();
                        getAssettype.Asset_Type = "AMC/Ins";
                        getAssettype.count= Convert.ToInt32(ds.Tables[0].Rows[0]["AMC_INS_Count"]);

                        assetlist.Add(getAssettype);
                       

                    }
                    if (ds.Tables[1].Rows.Count > 0)
                    {
                       
                        GetAssetTypeCount getAssettype = new GetAssetTypeCount();
                        getAssettype.Asset_Type = "Repair";
                        getAssettype.count = Convert.ToInt32(ds.Tables[1].Rows[0]["Repair_Count"]);

                        assetlist.Add(getAssettype);

                    }
                   /* if (ds.Tables[2].Rows.Count > 0)
                    {
                        GetAssetTypeCount getAssettype = new GetAssetTypeCount();
                        getAssettype.Asset_Type = "Total";
                        getAssettype.count = Convert.ToInt32(ds.Tables[2].Rows[0]["TotalAssets"]);

                        assetlist.Add(getAssettype);
                       
                  
                    }*/
                    if (ds.Tables[2].Rows.Count > 0)
                    {
                        GetAssetTypeCount getAssettype = new GetAssetTypeCount();
                        getAssettype.Asset_Type = "Move";
                        getAssettype.count = Convert.ToInt32(ds.Tables[2].Rows[0]["MoveAssets"]);

                        assetlist.Add(getAssettype);
                       
                       
                    }

                    if (ds.Tables[3].Rows.Count > 0)
                    {
                      
                        GetAssetTypeCount getAssettype = new GetAssetTypeCount();
                        getAssettype.Asset_Type = "Dispose";
                        getAssettype.count = Convert.ToInt32(ds.Tables[3].Rows[0]["DisposeAssets"]);

                        assetlist.Add(getAssettype);

                    }
                    response.GetAssetTypeCount = assetlist;
                    response.Msg = "Success";
                    response.Status = "true";
                }
                else
                {
                    response.Status = "false";
                    response.Msg = st;
                }
            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }


    }
}