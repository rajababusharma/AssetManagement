﻿using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Mail;
using System.Web;
using System.Web.Mail;

namespace AssetManagementAPI.BLL
{
    public class SendMailBLL
    {
        public PostResponse SendMail(string to, string pwd)
        {
            PostResponse response = new PostResponse();
            try {

                    System.Net.Mail.MailMessage msgs = new System.Net.Mail.MailMessage();
                    msgs.To.Add(to);
                    MailAddress address = new MailAddress("noreply@anichedigital.in");
                    msgs.From = address;
                    msgs.Subject = "Password Recovery Mail";
                   
                    msgs.Body = "You have successfully recovered your password. Your password is :"+pwd;
                    msgs.IsBodyHtml = false;
                    SmtpClient client = new SmtpClient();
                    client.Host = "smtpout.secureserver.net";
                    client.Port = 465;
                    client.UseDefaultCredentials = true;
                    client.DeliveryMethod = SmtpDeliveryMethod.Network;
                    client.Credentials = new System.Net.NetworkCredential("noreply@anichedigital.in", "aniche@12345");
                    //Send the msgs  
                    client.Send(msgs);
                    response.Msg = "Success";
                    response.Status = "true";
                   
        }
            catch (Exception ex)
            {
                response.Msg = ex.Message;
                response.Status = "false";
                Exception ex2 = ex;
                string errorMessage = string.Empty;
                while (ex2 != null)
                {
                    errorMessage += ex2.ToString();
                    ex2 = ex2.InnerException;
                }
               // Page.RegisterStartupScript("UserMsg", "<script>alert('Sending Failed...');if(alert){ window.location='SendMail.aspx';}</script>");
            }

            return response;
        }

        public PostResponse SendMail1(string to, string pwd)
        {
            PostResponse response = new PostResponse();
            try
            {
                System.Net.Mail.MailMessage msgs = new System.Net.Mail.MailMessage();
                msgs.To.Add(to);
                MailAddress address = new MailAddress("noreply@aniche-solutions.com");
                msgs.From = address;
                msgs.Subject = "Password Recovery Mail";

                msgs.Body = "You have successfully recovered your password. You password is :" + pwd;
                msgs.IsBodyHtml = false;
                SmtpClient client = new SmtpClient();
                client.Host = "relay-hosting.secureserver.net";
                client.Port = 25;
                client.UseDefaultCredentials = false;
                client.Credentials = new System.Net.NetworkCredential("noreply@aniche-solutions.com", "Software@989!");
                //Send the msgs  
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.Send(msgs);
                response.Msg = "Success";
                response.Status = "true";
               
            }
            catch (Exception ex)
            {
                response.Msg = ex.Message;
                response.Status = "false";
                Exception ex2 = ex;
                string errorMessage = string.Empty;
                while (ex2 != null)
                {
                    errorMessage += ex2.ToString();
                    ex2 = ex2.InnerException;
                }
                // Page.RegisterStartupScript("UserMsg", "<script>alert('Sending Failed...');if(alert){ window.location='SendMail.aspx';}</script>");
            }

            return response;
        }
    }
}