﻿using AssetManagementAPI.DatabaseHelper;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace AssetManagementAPI.BLL
{
    public class LoginBLL
    {
        DBConnection con;
        public LoginResponse UserLogin(string username, string password)
        {
            DataSet ds = new DataSet();
            string st = "You have entered invalid user name or password. Please try again later";

            LoginResponse response = new LoginResponse();
            try
            {
               
                SqlParameter prm1 = new SqlParameter("@user_name", username);
                SqlParameter prm2 = new SqlParameter("@password", password);

                using (con = new DBConnection())
                {
                    SqlParameter[] parameters = { prm1, prm2 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "ast_mobile_login", parameters);
                }


                UserDetails userDetails = new UserDetails();
                if (ds.Tables[0].Rows.Count > 0 && ds.Tables[1].Rows.Count > 0)
                    {
                       
                           
                           userDetails.Company_Id= ds.Tables[0].Rows[0]["Company_Id"].ToString();
                            userDetails.User_Code = ds.Tables[0].Rows[0]["User_Code"].ToString();
                            userDetails.Department = ds.Tables[0].Rows[0]["Department"].ToString();
                        userDetails.Location = ds.Tables[0].Rows[0]["Location"].ToString();
                        userDetails.Branch = ds.Tables[0].Rows[0]["Branch"].ToString();
                        userDetails.Emp_Name = ds.Tables[0].Rows[0]["Emp_Name"].ToString();
                        userDetails.User_Name = ds.Tables[0].Rows[0]["User_Name"].ToString();
                    userDetails.Pic = ds.Tables[0].Rows[0]["pic"].ToString();
                    userDetails.Manage_Assets = Convert.ToBoolean(ds.Tables[1].Rows[0]["Manage Assets"]);
                    userDetails.Move_Asset = Convert.ToBoolean(ds.Tables[1].Rows[0]["Move Asset"]);
                    userDetails.Repair_Asset = Convert.ToBoolean(ds.Tables[1].Rows[0]["Repair Asset"]);
                    userDetails.Transfer_Asset = Convert.ToBoolean(ds.Tables[1].Rows[0]["Transfer Asset"]);
                    userDetails.Dispose_Asset = Convert.ToBoolean(ds.Tables[1].Rows[0]["Dispose Asset"]);
                    userDetails.Rights_Managment = Convert.ToBoolean(ds.Tables[1].Rows[0]["Rights Managment"]);

                    response.UserDetails = userDetails;
                            response.Msg = "Success";
                            response.Status= "true";
                      

                      
                    
                }
                else
                {
                    response.Status = "false";
                    response.Msg = st;
                }
            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }
    }
}