﻿using AssetManagementAPI.DatabaseHelper;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace AssetManagementAPI.BLL
{
    public class InsertIntoTransferBLL
    {
        DBConnection con;

        public PostResponse InsertIntoTransfer(PostAssetTransferRequest request)
        {
            DateTime timeStamp = DateTime.Today;

            DataSet ds = new DataSet();
            string st = "";


            PostResponse response = new PostResponse();
            try
            {

                SqlParameter parameter1 = new SqlParameter("@Company_Id", request.Company_Id);
                SqlParameter parameter2 = new SqlParameter("@FinancialYear", request.FinancialYear);
                SqlParameter parameter3 = new SqlParameter("@Asset_id", request.Asset_id);
                SqlParameter parameter4 = new SqlParameter("@Asset_name", request.Asset_name);
                SqlParameter parameter5 = new SqlParameter("@Description", request.Description);
                SqlParameter parameter6 = new SqlParameter("@From_Employee", request.From_Employee);
                SqlParameter parameter7 = new SqlParameter("@To_Employee", request.To_Employee);
                SqlParameter parameter8 = new SqlParameter("@AssetTransfer_Date", request.AssetTransfer_Date);
               

                using (con = new DBConnection())
                {
                    SqlParameter[] parameters = { parameter1, parameter2, parameter3, parameter4, parameter5, parameter6, parameter7, parameter8};
                    SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "InsertIntoAssetTransfer", parameters);
                }



                response.Msg = "Success";

                response.Status = "true";

            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }
    }
}