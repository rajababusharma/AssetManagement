﻿using AssetManagementAPI.DatabaseHelper;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace AssetManagementAPI.BLL
{
    public class PostMoveAssetBLL
    {
        DBConnection con;

        public PostResponse PostStockTally(POST_MoveAssetDataRequest request)
        {
            DateTime timeStamp = DateTime.Today;

            DataSet ds = new DataSet();
            string st = "";
           
          
            PostResponse response = new PostResponse();
            try
            {
               
                SqlParameter parameter1 = new SqlParameter("@Param1", request.Company_Id);
                SqlParameter parameter2 = new SqlParameter("@Param2", request.Asset_id);
                SqlParameter parameter3 = new SqlParameter("@Param3", request.Asset_name);
                SqlParameter parameter4 = new SqlParameter("@Param4", request.From_Location_Description);
                SqlParameter parameter5 = new SqlParameter("@Param5", request.To_Location_Description);
                SqlParameter parameter6 = new SqlParameter("@Param6", request.From_Floor);
                SqlParameter parameter7 = new SqlParameter("@Param7", request.To_Floor);
                SqlParameter parameter8 = new SqlParameter("@Param8", request.Employee);
                SqlParameter parameter9 = new SqlParameter("@Param9", request.AssetMove_Date);
                SqlParameter parameter10 = new SqlParameter("@Param10", request.Status);
                SqlParameter parameter11 = new SqlParameter("@Param11", request.Remarks);
                SqlParameter parameter12 = new SqlParameter("@Param12", request.Img1);
                SqlParameter parameter13 = new SqlParameter("@Param13", request.Img2);
                SqlParameter parameter14 = new SqlParameter("@Param14", request.Img3);

                using (con = new DBConnection())
                {
                    SqlParameter[] parameters = { parameter1, parameter2, parameter3, parameter4, parameter5, parameter6, parameter7, parameter8, parameter9, parameter10, parameter11, parameter12, parameter13, parameter14 };
                    SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "Insert_IntoMoveMaster", parameters);
                }
               


                response.Msg = "Success";

                response.Status = "true";

            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }

        public PostResponse UpdateMoveAsset(string Asset_id,string To_Floor,string ToLocation)
        {
           // DateTime timeStamp = DateTime.Today;

            DataSet ds = new DataSet();
            string st = "";


            PostResponse response = new PostResponse();
            try
            {

                SqlParameter parameter1 = new SqlParameter("@AssetId", Asset_id);
                SqlParameter parameter2 = new SqlParameter("@tobranch", To_Floor);
                SqlParameter parameter3 = new SqlParameter("@tolocation", ToLocation);

                using (con = new DBConnection())
                {
                    SqlParameter[] parameters = { parameter1, parameter2, parameter3 };
                    SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "UpdateMoveAsset", parameters);
                }



                response.Msg = "Success";

                response.Status = "true";

            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }
    }
}