﻿using AssetManagementAPI.DatabaseHelper;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace AssetManagementAPI.BLL
{
    public class RecoverPasswordBLL
    {
        DBConnection con;
        public RecoverPasswordResp GetPasswordRecover(string email)
        {
            DataSet ds = new DataSet();
            string st = "No record found";

            RecoverPasswordResp response = new RecoverPasswordResp();
            try
            {

                 SqlParameter prm1 = new SqlParameter("@user_name", email);


                using (con = new DBConnection())
                {
                     SqlParameter[] parameters = { prm1 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "GetUsernametoRecover",parameters);
                }


                RecoverPassword recover = new RecoverPassword();
                if (ds.Tables[0].Rows.Count > 0)
                {



                    recover.Emp_Name = ds.Tables[0].Rows[0]["Emp_Name"].ToString();
                    recover.Password = ds.Tables[0].Rows[0]["Password"].ToString();
                    recover.User_Name = ds.Tables[0].Rows[0]["User_Name"].ToString();

                    response.recoverPassword = recover;
                    response.Msg = "Success";
                    response.Status = "true";

                }
                else
                {
                    response.Status = "false";
                    response.Msg = st;
                }
            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }
    }
}