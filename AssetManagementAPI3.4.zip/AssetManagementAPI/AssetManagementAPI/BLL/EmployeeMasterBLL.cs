﻿using AssetManagementAPI.DatabaseHelper;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace AssetManagementAPI.BLL
{
    public class EmployeeMasterBLL
    {
        DBConnection con;
        public EmployeeMasterResp GetEmployee(string Branch)
        {
            DataSet ds = new DataSet();
            string st = "No record found";

            EmployeeMasterResp response = new EmployeeMasterResp();
            try
            {

                 SqlParameter prm1 = new SqlParameter("@Branch", Branch);


                using (con = new DBConnection())
                {
                     SqlParameter[] parameters = { prm1 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "GetEmployeeList",parameters);
                }


                List<string> emplist = new List<string>();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                    {



                        emplist.Add(ds.Tables[0].Rows[i]["Emp_Name"].ToString());
                       // emplist.Add(ds.Tables[0].Rows[i]["Emp_code"].ToString());
                       // emplist.Add(ds.Tables[0].Rows[i]["Department"].ToString());

                    }
                    response.Employee = emplist;
                    response.Msg = "Success";
                    response.Status = "true";

                }
                else
                {
                    response.Status = "false";
                    response.Msg = st;
                }
            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }

        public PostResponse InsertEmployee(CreateEmployeeRequest request)
        {
            DataSet ds = new DataSet();
            string st = "No record found";

            PostResponse response = new PostResponse();
            try
            {

                SqlParameter prm1 = new SqlParameter("@Company_Id", request.Company_Id);
                SqlParameter prm2 = new SqlParameter("@Emp_code", request.Emp_code);
                SqlParameter prm3 = new SqlParameter("@Emp_Name", request.Emp_Name);
                SqlParameter prm4 = new SqlParameter("@Department", request.Department);
                SqlParameter prm5 = new SqlParameter("@Location", request.Location);
                SqlParameter prm6 = new SqlParameter("@Branch", request.Branch);
                SqlParameter prm7 = new SqlParameter("@Contact", request.Contact);
                SqlParameter prm8 = new SqlParameter("@EmailId", request.EmailId);


                using (con = new DBConnection())
                {
                    SqlParameter[] parameters = { prm1,prm2, prm3, prm4, prm5, prm6, prm7, prm8 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "CreateEmplooyee", parameters);
                }

                response.Msg = "Success";
                response.Status = "true";

            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }
    }
}