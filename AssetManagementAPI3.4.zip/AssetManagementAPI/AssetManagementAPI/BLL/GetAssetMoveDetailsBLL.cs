﻿using AssetManagementAPI.DatabaseHelper;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace AssetManagementAPI.BLL
{
    public class GetAssetMoveDetailsBLL
    {
        DBConnection con;
        public AssetMoveDetailResponse GetAssetMoveDataList(string Branch)
        {
            AssetMoveDetailResponse response = new AssetMoveDetailResponse();
            DataSet ds = new DataSet();
            string st = "No record found";


            try
            {

                 SqlParameter prm1 = new SqlParameter("@Branch", Branch);


                using (con = new DBConnection())
                {
                     SqlParameter[] parameters = { prm1 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "GetAssetsMoveDetails",parameters);
                }


                List<AssetMoveList> stockDetailslist = new List<AssetMoveList>();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                    {
                        AssetMoveList stockDetails = new AssetMoveList();
                        stockDetails.Company_Id = ds.Tables[0].Rows[i]["Company_Id"].ToString();
                        stockDetails.Asset_id = ds.Tables[0].Rows[i]["Asset_id"].ToString();
                        stockDetails.Asset_name = ds.Tables[0].Rows[i]["Asset_name"].ToString();
                        stockDetails.From_Location_Description = ds.Tables[0].Rows[i]["From_Location_Description"].ToString();
                        stockDetails.To_Location_Description = ds.Tables[0].Rows[i]["To_Location_Description"].ToString();
                        stockDetails.From_Floor = ds.Tables[0].Rows[i]["From_Floor"].ToString();
                        stockDetails.To_Floor = ds.Tables[0].Rows[i]["To_Floor"].ToString();
                        stockDetails.From_FinalLocation = ds.Tables[0].Rows[i]["From_FinalLocation"].ToString();
                        stockDetails.To_FinalLocation = ds.Tables[0].Rows[i]["To_FinalLocation"].ToString();
                        stockDetails.Employee = ds.Tables[0].Rows[i]["Employee"].ToString();
                        stockDetails.AssetMove_Date = ds.Tables[0].Rows[i]["AssetMove_Date"].ToString();
                        stockDetails.Status = Convert.ToBoolean(ds.Tables[0].Rows[i]["Status"]);
                        stockDetails.Remarks = ds.Tables[0].Rows[i]["Remarks"].ToString();
                        stockDetails.Image1 = ds.Tables[0].Rows[i]["Img1"].ToString();
                        stockDetails.Image2 = ds.Tables[0].Rows[i]["Img2"].ToString();
                        stockDetails.Image3 = ds.Tables[0].Rows[i]["Img3"].ToString();



                        stockDetailslist.Add(stockDetails);

                    }
                    response.AssetMoveList = stockDetailslist;
                    response.Msg = "Success";
                    response.Status = "true";

                }
                else
                {
                    response.Status = "false";
                    response.Msg = st;
                }
            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;

        }

        public AssetMoveDetailResponse GetMoveNotifications(string toBranch)
        {
            AssetMoveDetailResponse response = new AssetMoveDetailResponse();
            DataSet ds = new DataSet();
            string st = "No record found";


            try
            {

                SqlParameter prm1 = new SqlParameter("@tobranch", toBranch);


                using (con = new DBConnection())
                {
                    SqlParameter[] parameters = { prm1 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "GetMoveNotification", parameters);
                }


                List<AssetMoveList> stockDetailslist = new List<AssetMoveList>();
                List<AMCList> amclist = new List<AMCList>();
                List<InsuranceList> inslist = new List<InsuranceList>();
                if (ds.Tables[0].Rows.Count > 0 || ds.Tables[1].Rows.Count > 0 || ds.Tables[2].Rows.Count > 0)
                {
                if (ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                    {
                        AssetMoveList stockDetails = new AssetMoveList();
                        stockDetails.Company_Id = ds.Tables[0].Rows[i]["Company_Id"].ToString();
                        stockDetails.Asset_id = ds.Tables[0].Rows[i]["Asset_id"].ToString();
                        stockDetails.Asset_name = ds.Tables[0].Rows[i]["Asset_name"].ToString();
                        stockDetails.From_Location_Description = ds.Tables[0].Rows[i]["From_Location_Description"].ToString();
                        stockDetails.To_Location_Description = ds.Tables[0].Rows[i]["To_Location_Description"].ToString();
                        stockDetails.From_Floor = ds.Tables[0].Rows[i]["From_Floor"].ToString();
                        stockDetails.To_Floor = ds.Tables[0].Rows[i]["To_Floor"].ToString();
                        stockDetails.From_FinalLocation = ds.Tables[0].Rows[i]["From_FinalLocation"].ToString();
                        stockDetails.To_FinalLocation = ds.Tables[0].Rows[i]["To_FinalLocation"].ToString();
                        stockDetails.Employee = ds.Tables[0].Rows[i]["Employee"].ToString();
                        stockDetails.AssetMove_Date = ds.Tables[0].Rows[i]["AssetMove_Date"].ToString();
                        stockDetails.Status = Convert.ToBoolean(ds.Tables[0].Rows[i]["Status"]);
                        stockDetails.Remarks = ds.Tables[0].Rows[i]["Remarks"].ToString();




                        stockDetailslist.Add(stockDetails);

                    }
                    response.AssetMoveList = stockDetailslist;
                    response.Msg = "Success";
                    response.Status = "true";

                }
                if (ds.Tables[1].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables[1].Rows.Count - 1; i++)
                    {
                        AMCList stockDetails = new AMCList();
                        stockDetails.Company_Id = ds.Tables[1].Rows[i]["Company_Id"].ToString();
                        stockDetails.Asset_id = ds.Tables[1].Rows[i]["Asset_id"].ToString();
                        stockDetails.Asset_Name = ds.Tables[1].Rows[i]["Asset_Name"].ToString();
                        stockDetails.Branch = ds.Tables[1].Rows[i]["Branch"].ToString();
                        stockDetails.Vendor_Name = ds.Tables[1].Rows[i]["Vendor_Name"].ToString();
                        stockDetails.AMC_Type = ds.Tables[1].Rows[i]["AMC_Type"].ToString();
                        stockDetails.AMC_StartDate = Convert.ToDateTime(ds.Tables[1].Rows[i]["AMC_StartDate"]);
                        stockDetails.AMC_EndDate = Convert.ToDateTime(ds.Tables[1].Rows[i]["AMC_EndDate"]);
                        stockDetails.AMC_AlertDate = Convert.ToDateTime(ds.Tables[1].Rows[i]["AMC_AlertDate"]);
                        stockDetails.AMC_Description = ds.Tables[1].Rows[i]["AMC_Description"].ToString();
                        stockDetails.AMC_Value = ds.Tables[1].Rows[i]["AMC_Value"].ToString();
                        stockDetails.Image1 = ds.Tables[1].Rows[i]["Image1"].ToString();
                        amclist.Add(stockDetails);

                    }
                    response.AMCLists = amclist;
                    response.Msg = "Success";
                    response.Status = "true";

                }
                if (ds.Tables[2].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables[2].Rows.Count - 1; i++)
                    {
                            InsuranceList stockDetails = new InsuranceList();
                        stockDetails.Company_Id = ds.Tables[2].Rows[i]["Company_Id"].ToString();
                        stockDetails.Asset_id = ds.Tables[2].Rows[i]["Asset_id"].ToString();
                        stockDetails.Asset_Name = ds.Tables[2].Rows[i]["Asset_Name"].ToString();
                        stockDetails.Branch = ds.Tables[2].Rows[i]["Branch"].ToString();
                        stockDetails.Policy_Date = Convert.ToDateTime(ds.Tables[2].Rows[i]["Policy_Date"]);
                        stockDetails.InsuranceCompany_Name = ds.Tables[2].Rows[i]["InsuranceCompany_Name"].ToString();
                        stockDetails.Policy_No = ds.Tables[2].Rows[i]["Policy_No"].ToString();
                        stockDetails.Alert_Date = Convert.ToDateTime(ds.Tables[2].Rows[i]["Alert_Date"]);
                        stockDetails.Policy_Name = ds.Tables[2].Rows[i]["Policy_Name"].ToString();
                        stockDetails.Premium = ds.Tables[2].Rows[i]["Premium"].ToString();
                        stockDetails.Due_Date = Convert.ToDateTime(ds.Tables[2].Rows[i]["Due_Date"]);
                            stockDetails.ModeOFPayment = ds.Tables[2].Rows[i]["ModeOFPayment"].ToString();
                            stockDetails.Image1 = ds.Tables[2].Rows[i]["Image1"].ToString();
                        inslist.Add(stockDetails);

                    }
                    response.insuranceLists = inslist;
                    response.Msg = "Success";
                    response.Status = "true";

                }
            }
                else
                {
                    response.Status = "false";
                    response.Msg = st;
                }
            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }
    }
}