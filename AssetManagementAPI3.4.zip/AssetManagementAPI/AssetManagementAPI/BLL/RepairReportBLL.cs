﻿using AssetManagementAPI.DatabaseHelper;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace AssetManagementAPI.BLL
{
    public class RepairReportBLL
    {
        DBConnection con;
        public AssetRepairResponse GetAssetRepairList()
        {
            AssetRepairResponse response = new AssetRepairResponse();
            DataSet ds = new DataSet();
            string st = "No record found";

           
            try
            {

               // SqlParameter prm1 = new SqlParameter("@Branch", Branch);


                using (con = new DBConnection())
                {
                   // SqlParameter[] parameters = { prm1 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "GetAssetRepairDetails");
                }


                List<AssetRepairList> stockDetailslist = new List<AssetRepairList>();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                    {
                        AssetRepairList stockDetails = new AssetRepairList();
                        stockDetails.Company_Id = ds.Tables[0].Rows[i]["Company_Id"].ToString();
                        stockDetails.Asset_id = ds.Tables[0].Rows[i]["Asset_id"].ToString();
                        stockDetails.Asset_name = ds.Tables[0].Rows[i]["Asset_name"].ToString();
                        stockDetails.Description = ds.Tables[0].Rows[i]["Description"].ToString();
                        stockDetails.ReasonFor_Repair = ds.Tables[0].Rows[i]["ReasonFor_Repair"].ToString();
                        stockDetails.ExpectedReturn_Date = ds.Tables[0].Rows[i]["ExpectedReturn_Date"].ToString();
                        stockDetails.Vendor_Name = ds.Tables[0].Rows[i]["Vendor_Name"].ToString();
                        stockDetails.Authorized_By = ds.Tables[0].Rows[i]["Authorized_By"].ToString();
                        stockDetails.Repair_Charge = ds.Tables[0].Rows[i]["Repair_Charge"].ToString();
                        stockDetails.IsReturned = Convert.ToInt32( ds.Tables[0].Rows[i]["IsReturned"]);
                        stockDetails.Returned_On = ds.Tables[0].Rows[i]["Returned_On"].ToString();
                        stockDetails.ReasonFor_Delay = ds.Tables[0].Rows[i]["ReasonFor_Delay"].ToString();
                        stockDetails.Location_Code = ds.Tables[0].Rows[i]["Location_Code"].ToString();
                        stockDetails.Cdate = ds.Tables[0].Rows[i]["Cdate"].ToString();

                        stockDetails.Image1 = ds.Tables[0].Rows[i]["Img1"].ToString();
                        stockDetails.Image2 = ds.Tables[0].Rows[i]["Img2"].ToString();
                        stockDetails.Image3 = ds.Tables[0].Rows[i]["Img3"].ToString();
                        stockDetailslist.Add(stockDetails);

                    }
                    response.AssetRepairList = stockDetailslist;
                    response.Msg = "Success";
                    response.Status = "true";

                }
                else
                {
                    response.Status = "false";
                    response.Msg = st;
                }
            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;

        }

        public PostResponse UpdateIsReturned(string Asset_id)
        {
            // DateTime timeStamp = DateTime.Today;

            DataSet ds = new DataSet();
            string st = "";


            PostResponse response = new PostResponse();
            try
            {

                SqlParameter parameter1 = new SqlParameter("@AssetId", Asset_id);
             


                using (con = new DBConnection())
                {
                    SqlParameter[] parameters = { parameter1};
                    SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "IsAssetReturned", parameters);
                }



                response.Msg = "Success";

                response.Status = "true";

            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }
    }
}