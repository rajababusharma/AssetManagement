﻿using AssetManagementAPI.DatabaseHelper;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace AssetManagementAPI.BLL
{
    public class DepartmentBLL
    {
        DBConnection con;
        internal PostResponse CreateDepartment(CreateDepartmentRequest request)
        {
            DataSet ds = new DataSet();
            string st = "No record found";

            PostResponse response = new PostResponse();
            try
            {

                SqlParameter prm1 = new SqlParameter("@Company_Id", request.Company_Id);
                SqlParameter prm2 = new SqlParameter("@Department", request.Department);
               


                using (con = new DBConnection())
                {
                    SqlParameter[] parameters = { prm1, prm2 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "CreateDepartment", parameters);
                }




                response.Msg = "Success";
                response.Status = "true";


            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }
    }
}