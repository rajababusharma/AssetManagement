﻿using AssetManagementAPI.DatabaseHelper;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace AssetManagementAPI.BLL
{
    public class GetUsersListBLL
    {
        DBConnection con;
        public UserMasterResp GetUserList()
        {
            DataSet ds = new DataSet();
            string st = "No record found";

            UserMasterResp response = new UserMasterResp();
            try
            {

               // SqlParameter prm1 = new SqlParameter("@Branch", Branch);


                using (con = new DBConnection())
                {
                   // SqlParameter[] parameters = { prm1 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "GetAllUsers");
                }


                List<string> emplist = new List<string>();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                    {



                        emplist.Add(ds.Tables[0].Rows[i]["User_Name"].ToString());
                        // emplist.Add(ds.Tables[0].Rows[i]["Emp_code"].ToString());
                        // emplist.Add(ds.Tables[0].Rows[i]["Department"].ToString());

                    }
                    response.Users = emplist;
                    response.Msg = "Success";
                    response.Status = "true";

                }
                else
                {
                    response.Status = "false";
                    response.Msg = st;
                }
            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }

        public UserRightsResp GetUsersRight(string user)
        {
            DataSet ds = new DataSet();
            string st = "No record found";

            UserRightsResp response = new UserRightsResp();
            try
            {

                 SqlParameter prm1 = new SqlParameter("@User", user);


                using (con = new DBConnection())
                {
                     SqlParameter[] parameters = { prm1 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "GetUserRights",parameters);
                }


                UserRights rightslist = new UserRights();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                    {



                        rightslist.Manage_Assets=Convert.ToBoolean (ds.Tables[0].Rows[i]["Manage Assets"]);
                        rightslist.Move_Asset = Convert.ToBoolean(ds.Tables[0].Rows[i]["Move Asset"]);
                        rightslist.Repair_Asset = Convert.ToBoolean(ds.Tables[0].Rows[i]["Repair Asset"]);
                        rightslist.Transfer_Asset = Convert.ToBoolean(ds.Tables[0].Rows[i]["Transfer Asset"]);
                        rightslist.Dispose_Asset = Convert.ToBoolean(ds.Tables[0].Rows[i]["Dispose Asset"]);
                        rightslist.Rights_Managment = Convert.ToBoolean(ds.Tables[0].Rows[i]["Rights Managment"]);
                        // emplist.Add(ds.Tables[0].Rows[i]["Emp_code"].ToString());
                        // emplist.Add(ds.Tables[0].Rows[i]["Department"].ToString());

                    }
                    response.UsersRights = rightslist;
                    response.Msg = "Success";
                    response.Status = "true";

                }
                else
                {
                    response.Status = "false";
                    response.Msg = st;
                }
            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }

        public PostResponse InsertIntoUserRights(PostUsersRightRequest user)
        {
            DataSet ds = new DataSet();
            string st = "No record found";

            PostResponse response = new PostResponse();
            try
            {

                SqlParameter prm1 = new SqlParameter("@Company_Id", user.Company_Id);
                SqlParameter prm2 = new SqlParameter("@User", user.User);
                SqlParameter prm3 = new SqlParameter("@ManageAsset", user.Manage_Assets);
                SqlParameter prm4 = new SqlParameter("@MoveAsset", user.Move_Asset);
                SqlParameter prm5 = new SqlParameter("@TransferAsset", user.Transfer_Asset);
                SqlParameter prm6 = new SqlParameter("@DisposeAsset", user.Dispose_Asset);
                SqlParameter prm7 = new SqlParameter("@RepairAsset", user.Repair_Asset);
                SqlParameter prm8 = new SqlParameter("@RightsManage", user.Rights_Managment);


                using (con = new DBConnection())
                {
                    SqlParameter[] parameters = { prm1,prm2,prm3,prm4,prm5,prm6,prm7,prm8 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "InsertIntoUserMenuRights", parameters);
                }


             
                 
                    response.Msg = "Success";
                    response.Status = "true";

           
            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }

        public PostResponse CreateUsers(CreateUserRequest users)
        {
            DataSet ds = new DataSet();
            string st = "No record found";

            PostResponse response = new PostResponse();
            try
            {

                SqlParameter prm1 = new SqlParameter("@Company_Id", users.Company_Id);
                SqlParameter prm2 = new SqlParameter("@User_Code", users.User_Code);
                SqlParameter prm3 = new SqlParameter("@User_Name", users.User_Name);
                SqlParameter prm4 = new SqlParameter("@Password", users.Password);
                SqlParameter prm5 = new SqlParameter("@IsActive", users.IsActive);
                SqlParameter prm6 = new SqlParameter("@Cdate", users.Cdate);
                SqlParameter prm7 = new SqlParameter("@Emp_Name", users.Emp_Name);

                SqlParameter prm8 = new SqlParameter("@Department", users.Department);
                SqlParameter prm9 = new SqlParameter("@Location", users.Location);
                SqlParameter prm10 = new SqlParameter("@Branch", users.Branch);
                SqlParameter prm11 = new SqlParameter("@Contact", users.Contact);
                SqlParameter prm12 = new SqlParameter("@EmailId", users.EmailId);
                SqlParameter prm13 = new SqlParameter("@pic", users.pic);



                using (con = new DBConnection())
                {
                    SqlParameter[] parameters = { prm1, prm2, prm3, prm4, prm5, prm6, prm7,prm8, prm9, prm10, prm11, prm12, prm13 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "CreateUsers", parameters);
                }




                response.Msg = "Success";
                response.Status = "true";


            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }
    }
}