﻿using AssetManagementAPI.DatabaseHelper;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace AssetManagementAPI.BLL
{
    public class AssetCategoryCountBLL
    {
        DBConnection con;
        public AssetCategoryCountResp GetStockTally(string Branch)
        {
            DataSet ds = new DataSet();
            string st = "No record found";

            AssetCategoryCountResp response = new AssetCategoryCountResp();
            try
            {

                SqlParameter prm1 = new SqlParameter("@Branch", Branch);


                using (con = new DBConnection())
                {
                    SqlParameter[] parameters = { prm1 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "GetAssetCategoryCount", parameters);
                }


                List<AssetCategoryCountList> stockDetailslist = new List<AssetCategoryCountList>();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                    {
                        AssetCategoryCountList stockDetails = new AssetCategoryCountList();
                        stockDetails.AssetCategory = ds.Tables[0].Rows[i]["AssetCategory"].ToString();
                        stockDetails.Count = ds.Tables[0].Rows[i]["Count"].ToString();
                       
                        stockDetailslist.Add(stockDetails);

                    }
                    response.AssetCategoryCountList = stockDetailslist;
                    response.Msg = "Success";
                    response.Status = "true";

                }
                else
                {
                    response.Status = "false";
                    response.Msg = st;
                }
            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }
    }
}