﻿using AssetManagementAPI.DatabaseHelper;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;

namespace AssetManagementAPI.BLL
{
    public class InsuranceReportBLL
    {
        DBConnection con;
        public InsuranceDetailResponse GetAssetInsuranceList()
        {
            InsuranceDetailResponse response = new InsuranceDetailResponse();
            DataSet ds = new DataSet();
            string st = "No record found";


            try
            {

                // SqlParameter prm1 = new SqlParameter("@Branch", Branch);


                using (con = new DBConnection())
                {
                    // SqlParameter[] parameters = { prm1 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "GetInsuranceDetails");
                }


                List<InsuranceDetailList> stockDetailslist = new List<InsuranceDetailList>();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                    {
                        InsuranceDetailList stockDetails = new InsuranceDetailList();
                        stockDetails.Company_Id = ds.Tables[0].Rows[i]["Company_Id"].ToString();
                        stockDetails.Asset_id = ds.Tables[0].Rows[i]["Asset_id"].ToString();
                        stockDetails.Policy_Name = ds.Tables[0].Rows[i]["Policy_Name"].ToString();
                        stockDetails.Maturity_Date = ds.Tables[0].Rows[i]["Maturity_Date"].ToString();
                        stockDetails.Insurance_Date = ds.Tables[0].Rows[i]["Insurance_Date"].ToString();
                        stockDetails.Policy_No = ds.Tables[0].Rows[i]["Policy_No"].ToString();
                        stockDetails.InsuranceCompany_Name = ds.Tables[0].Rows[i]["InsuranceCompany_Name"].ToString();
                        stockDetails.Policy_Date = ds.Tables[0].Rows[i]["Policy_Date"].ToString();
                        stockDetails.Premium = ds.Tables[0].Rows[i]["Premium"].ToString();
                        stockDetails.Sum_Insured = ds.Tables[0].Rows[i]["Sum_Insured"].ToString();
                        stockDetails.ModeOFPayment = ds.Tables[0].Rows[i]["ModeOFPayment"].ToString();
                        stockDetails.Image1 = ds.Tables[0].Rows[i]["Image1"].ToString();
                        stockDetailslist.Add(stockDetails);

                    }
                    response.InsuranceDetailList = stockDetailslist;
                    response.Msg = "Success";
                    response.Status = "true";

                }
                else
                {
                    response.Status = "false";
                    response.Msg = st;
                }
            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;

        }
    }
}