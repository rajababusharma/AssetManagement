﻿using AssetManagementAPI.DatabaseHelper;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace AssetManagementAPI.BLL
{
    public class InsertIntoRepairAssetBLL
    {
        DBConnection con;

        public PostResponse InsertIntoRepair(PostAssetRepairRequest request)
        {
            DateTime timeStamp = DateTime.Today;

            DataSet ds = new DataSet();
            string st = "";


            PostResponse response = new PostResponse();
            try
            {

                SqlParameter parameter1 = new SqlParameter("@Company_Id", request.Company_Id);
                SqlParameter parameter2 = new SqlParameter("@FinancialYear", request.FinancialYear);
                SqlParameter parameter3 = new SqlParameter("@Asset_id", request.Asset_id);
                SqlParameter parameter4 = new SqlParameter("@Asset_name", request.Asset_name);
                SqlParameter parameter5 = new SqlParameter("@Description", request.Description);
                SqlParameter parameter6 = new SqlParameter("@ReasonFor_Repair", request.ReasonFor_Repair);
                SqlParameter parameter7 = new SqlParameter("@ExpectedReturn_Date", request.ExpectedReturn_Date);
                SqlParameter parameter8 = new SqlParameter("@Vendor_Name", request.Vendor_Name);
                SqlParameter parameter9 = new SqlParameter("@Authorized_By", request.Authorized_By);
                SqlParameter parameter10 = new SqlParameter("@Cdate", request.Cdate);
                SqlParameter parameter11 = new SqlParameter("@Location_Code", request.Location_Code);
                SqlParameter parameter12 = new SqlParameter("@Remarks", request.Remarks);
                SqlParameter parameter13 = new SqlParameter("@Img1", request.Img1);
                SqlParameter parameter14 = new SqlParameter("@Img2", request.Img2);
                SqlParameter parameter15 = new SqlParameter("@Img3", request.Img3);

                using (con = new DBConnection())
                {
                    SqlParameter[] parameters = { parameter1, parameter2, parameter3, parameter4, parameter5, parameter6, parameter7, parameter8, parameter9, parameter10, parameter11, parameter12, parameter13, parameter14, parameter15 };
                    SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "InsertIntoAssetRepair", parameters);
                }



                response.Msg = "Success";

                response.Status = "true";

            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }

       
    }
}