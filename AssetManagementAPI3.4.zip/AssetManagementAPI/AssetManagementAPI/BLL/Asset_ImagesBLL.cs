﻿using AssetManagementAPI.DatabaseHelper;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace AssetManagementAPI.BLL
{
    public class Asset_ImagesBLL
    {
        DBConnection con;
        public AssetsImagesResponse GetAssetImageList(string astid)
        {
            AssetsImagesResponse response = new AssetsImagesResponse();
            DataSet ds = new DataSet();
            string st = "No record found";


            try
            {

                 SqlParameter prm1 = new SqlParameter("@AssetId", astid);


                using (con = new DBConnection())
                {
                     SqlParameter[] parameters = { prm1 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "GetAssets_Images",parameters);
                }


                List<assetimages> imagelist = new List<assetimages>();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                    {
                        assetimages img = new assetimages();
                        img.ImageType = "Asset Purchase Document";
                        img.Images = ds.Tables[0].Rows[i]["FileName"].ToString();
                        imagelist.Add(img);
                        
                    }
                   

                }
                if (ds.Tables[1].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables[1].Rows.Count - 1; i++)
                    {
                        assetimages img1 = new assetimages();
                        img1.ImageType = "Asset Move Document";
                        img1.Images = ds.Tables[1].Rows[i]["Img1"].ToString();
                        assetimages img2 = new assetimages();
                        img2.ImageType = "Asset Move Document";
                        img2.Images = ds.Tables[1].Rows[i]["Img2"].ToString();
                        assetimages img3 = new assetimages();
                        img3.ImageType = "Asset Move Document";
                        img3.Images = ds.Tables[1].Rows[i]["Img3"].ToString();
                        imagelist.Add(img1);
                        imagelist.Add(img2);
                        imagelist.Add(img3);

                       
                    }


                }
                if (ds.Tables[2].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables[2].Rows.Count - 1; i++)
                    {
                        assetimages img1 = new assetimages();
                        img1.ImageType = "Asset Repair Document";
                        img1.Images = ds.Tables[2].Rows[i]["Img1"].ToString();
                        assetimages img2 = new assetimages();
                        img2.ImageType = "Asset Repair Document";
                        img2.Images = ds.Tables[2].Rows[i]["Img2"].ToString();
                        assetimages img3 = new assetimages();
                        img3.ImageType = "Asset Repair Document";
                        img3.Images = ds.Tables[2].Rows[i]["Img3"].ToString();
                        imagelist.Add(img1);
                        imagelist.Add(img2);
                        imagelist.Add(img3);
                    }


                }
                if (ds.Tables[3].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables[3].Rows.Count - 1; i++)
                    {
                        assetimages img1 = new assetimages();
                        img1.ImageType = "Asset Dispose Document";
                        img1.Images = ds.Tables[3].Rows[i]["Img1"].ToString();
                        assetimages img2 = new assetimages();
                        img2.ImageType = "Asset Dispose Document";
                        img2.Images = ds.Tables[3].Rows[i]["Img2"].ToString();
                        assetimages img3 = new assetimages();
                        img3.ImageType = "Asset Dispose Document";
                        img3.Images = ds.Tables[3].Rows[i]["Img3"].ToString();
                        imagelist.Add(img1);
                        imagelist.Add(img2);
                        imagelist.Add(img3);
                    }


                }
                if (ds.Tables[4].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables[4].Rows.Count - 1; i++)
                    {
                        assetimages img1 = new assetimages();
                        img1.ImageType = "Asset AMC Document";
                        img1.Images = ds.Tables[4].Rows[i]["Image1"].ToString();
                        imagelist.Add(img1);
                        
                    }


                }
                if (ds.Tables[5].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables[5].Rows.Count - 1; i++)
                    {
                       
                        assetimages img1 = new assetimages();
                        img1.ImageType = "Asset Insurance Document";
                        img1.Images = ds.Tables[5].Rows[i]["Image1"].ToString();
                        imagelist.Add(img1);
                    }


                }


               
                response.Images = imagelist;
                response.Msg = "Success";
                response.Status = "true";
            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;

        }
    }
}