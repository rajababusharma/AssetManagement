﻿using AssetManagementAPI.DatabaseHelper;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace AssetManagementAPI.BLL
{
    public class CreateAMCBLL
    {
        DBConnection con;
        internal PostResponse CreateAMC(AMCList request)
        {
            DataSet ds = new DataSet();
            string st = "No record found";

            PostResponse response = new PostResponse();
            try
            {

                SqlParameter prm1 = new SqlParameter("@Company_Id", request.Company_Id);
                SqlParameter prm2 = new SqlParameter("@Asset_id", request.Asset_id);
                SqlParameter prm3 = new SqlParameter("@Asset_Name", request.Asset_Name);
                SqlParameter prm4 = new SqlParameter("@Branch", request.Branch);
                SqlParameter prm5 = new SqlParameter("@Vendor_Name", request.Vendor_Name);
                SqlParameter prm6 = new SqlParameter("@AMC_Type", request.AMC_Type);
                SqlParameter prm7 = new SqlParameter("@AMC_StartDate", request.AMC_StartDate);
                SqlParameter prm8 = new SqlParameter("@AMC_EndDate", request.AMC_EndDate);
                SqlParameter prm9 = new SqlParameter("@AMC_AlertDate", request.AMC_AlertDate);
                SqlParameter prm10 = new SqlParameter("@AMC_Description", request.AMC_Description);
                SqlParameter prm11 = new SqlParameter("@AMC_Value", request.AMC_Value);
                SqlParameter prm12 = new SqlParameter("@Image1", request.Image1);
             


                using (con = new DBConnection())
                {
                    SqlParameter[] parameters = { prm1, prm2, prm3, prm4, prm5, prm6, prm7, prm8, prm9, prm10, prm11, prm12 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "CreateAMC", parameters);
                }




                response.Msg = "Success";
                response.Status = "true";


            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }

        internal PostResponse CreateInsurance(InsuranceList request)
        {
            DataSet ds = new DataSet();
            string st = "No record found";

            PostResponse response = new PostResponse();
            try
            {

                SqlParameter prm1 = new SqlParameter("@Company_Id", request.Company_Id);
                SqlParameter prm2 = new SqlParameter("@Asset_id", request.Asset_id);
                SqlParameter prm3 = new SqlParameter("@Asset_Name", request.Asset_Name);
                SqlParameter prm4 = new SqlParameter("@Branch", request.Branch);
                SqlParameter prm5 = new SqlParameter("@Policy_Date", request.Policy_Date);
                SqlParameter prm6 = new SqlParameter("@InsuranceCompany_Name", request.InsuranceCompany_Name);
                SqlParameter prm7 = new SqlParameter("@Policy_No", request.Policy_No);
                SqlParameter prm8 = new SqlParameter("@Alert_Date", request.Alert_Date);
                SqlParameter prm9 = new SqlParameter("@Policy_Name", request.Policy_Name);
                SqlParameter prm10 = new SqlParameter("@Premium", request.Premium);
                SqlParameter prm11 = new SqlParameter("@Due_Date", request.Due_Date);
                SqlParameter prm12 = new SqlParameter("@ModeOFPayment", request.ModeOFPayment);
                SqlParameter prm13 = new SqlParameter("@Image1", request.Image1);



                using (con = new DBConnection())
                {
                    SqlParameter[] parameters = { prm1, prm2, prm3, prm4, prm5, prm6, prm7, prm8, prm9, prm10, prm11, prm12,prm13 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "InsertInsurance", parameters);
                }




                response.Msg = "Success";
                response.Status = "true";


            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }
    }
}