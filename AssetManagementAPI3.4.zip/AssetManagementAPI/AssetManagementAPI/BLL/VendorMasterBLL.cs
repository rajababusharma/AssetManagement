﻿using AssetManagementAPI.DatabaseHelper;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace AssetManagementAPI.BLL
{
    public class VendorMasterBLL
    {
        DBConnection con;
        public VendorMasterResp GetVendorList()
        {
            DataSet ds = new DataSet();
            string st = "No record found";

            VendorMasterResp response = new VendorMasterResp();
            try
            {

               // SqlParameter prm1 = new SqlParameter("@Branch", Branch);


                using (con = new DBConnection())
                {
                   // SqlParameter[] parameters = { prm1 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "GetVendorList");
                }


                List<string> vendorlist = new List<string>();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                    {



                        vendorlist.Add(ds.Tables[0].Rows[i]["Vendor_Name"].ToString());
                        // emplist.Add(ds.Tables[0].Rows[i]["Emp_code"].ToString());
                        // emplist.Add(ds.Tables[0].Rows[i]["Department"].ToString());

                    }
                    response.Vendor = vendorlist;
                    response.Msg = "Success";
                    response.Status = "true";

                }
                else
                {
                    response.Status = "false";
                    response.Msg = st;
                }
            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }

        public PostResponse InsertVendor(CreateVendorRequest request)
        {
            DataSet ds = new DataSet();
            string st = "No record found";

            PostResponse response = new PostResponse();
            try
            {

                SqlParameter prm1 = new SqlParameter("@Company_Id", request.Company_Id);
                SqlParameter prm2 = new SqlParameter("@Vendor_code", request.Vendor_code);
                SqlParameter prm3 = new SqlParameter("@Vendor_Name", request.Vendor_Name);
                SqlParameter prm4 = new SqlParameter("@Address1", request.Address1);
                SqlParameter prm5 = new SqlParameter("@Address2", request.Address2);
                SqlParameter prm6 = new SqlParameter("@City", request.City);
                SqlParameter prm7 = new SqlParameter("@ZipCode", request.ZipCode);
                SqlParameter prm8 = new SqlParameter("@Contact", request.Contact);
                SqlParameter prm9 = new SqlParameter("@EmailId", request.EmailId);
                SqlParameter prm10 = new SqlParameter("@gstno", request.gstno);

                using (con = new DBConnection())
                {
                    SqlParameter[] parameters = { prm1, prm2, prm3, prm4, prm5, prm6, prm7, prm8,prm9,prm10 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "CreateVendor", parameters);
                }

                response.Msg = "Success";
                response.Status = "true";

            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }
    }
}