﻿using AssetManagementAPI.DatabaseHelper;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace AssetManagementAPI.BLL
{
    public class GetCat_SubCat_Dept_VenorBLL
    {
        DBConnection con;
        public Cate_Sub_Dept_VendorResp GetCat_Sub_Dept_Vendor()
        {
            DataSet ds = new DataSet();
            string st = "No record found";

            Cate_Sub_Dept_VendorResp response = new Cate_Sub_Dept_VendorResp();
            try
            {

               // SqlParameter prm1 = new SqlParameter("@Branch", Branch);


                using (con = new DBConnection())
                {
                   // SqlParameter[] parameters = { prm1 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "GetAsset_Cat_subcate_dept_ven");
                }


                List<string> categoryList = new List<string>();
                List<string> subCategoryList = new List<string>();
                List<string> departmentList = new List<string>();
                List<string> vendorList = new List<string>();
                List<string> branchlist = new List<string>();
                List<string> locationlist = new List<string>();

                if (ds.Tables[0].Rows.Count > 0)
                {
                    categoryList.Add("Select Asset Category");
                    for (int i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                    {
                        
                        categoryList.Add(ds.Tables[0].Rows[i]["Category_Description"].ToString());
                        

                    }
                    response.CategoryList = categoryList;
                    response.Msg = "Success";
                    response.Status = "true";

                }
                if (ds.Tables[1].Rows.Count > 0)
                {
                    subCategoryList.Add("Select Sub Category");
                    for (int i = 0; i <= ds.Tables[1].Rows.Count - 1; i++)
                    {
                       
                        subCategoryList.Add(ds.Tables[1].Rows[i]["SubCategory_Description"].ToString());

                    }
                    response.SubCategoryList = subCategoryList;
                    response.Msg = "Success";
                    response.Status = "true";

                }
                if (ds.Tables[2].Rows.Count > 0)
                {
                    vendorList.Add("Select Vendor");
                    for (int i = 0; i <= ds.Tables[2].Rows.Count - 1; i++)
                    {
                        
                        vendorList.Add(ds.Tables[2].Rows[i]["Vendor_Name"].ToString());

                    }
                    response.VendorList = vendorList;
                    response.Msg = "Success";
                    response.Status = "true";

                }
                if (ds.Tables[3].Rows.Count > 0)
                {
                    departmentList.Add("Select Department");
                    for (int i = 0; i <= ds.Tables[3].Rows.Count - 1; i++)
                    {
                        
                        departmentList.Add(ds.Tables[3].Rows[i]["Department"].ToString());

                    }
                    response.DepartmentList = departmentList;
                    response.Msg = "Success";
                    response.Status = "true";

                }
                
                if (ds.Tables[4].Rows.Count > 0)
                {
                    branchlist.Add("Select Branch");
                    for (int i = 0; i <= ds.Tables[4].Rows.Count - 1; i++)
                    {



                        branchlist.Add(ds.Tables[4].Rows[i]["Floor"].ToString());

                    }
                    response.BranchList = branchlist;
                    response.Msg = "Success";
                    response.Status = "true";

                }
                if (ds.Tables[5].Rows.Count > 0)
                {
                    locationlist.Add("Select Location");
                    for (int i = 0; i <= ds.Tables[5].Rows.Count - 1; i++)
                    {



                        locationlist.Add(ds.Tables[5].Rows[i]["Location_Description"].ToString());

                    }
                    response.LocationList = locationlist;
                    response.Msg = "Success";
                    response.Status = "true";

                }
                else
                {
                    response.Status = "false";
                    response.Msg = st;
                }
            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }

        internal PostResponse InsertSubCategory(CreateSubCategoryRequest request)
        {
            DataSet ds = new DataSet();
            string st = "No record found";

            PostResponse response = new PostResponse();
            try
            {

                SqlParameter prm1 = new SqlParameter("@Asset_Code", request.Asset_Code);
                SqlParameter prm2 = new SqlParameter("@Category_Description", request.Category_Description);
                SqlParameter prm3 = new SqlParameter("@SubCategory_Description", request.SubCategory_Description);


                using (con = new DBConnection())
                {
                    SqlParameter[] parameters = { prm1, prm2,prm3 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "CreateSubCategory", parameters);
                }

                response.Msg = "Success";
                response.Status = "true";

            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }

        internal PostResponse InsertCategory(CreateCategoryRequest request)
        {
            DataSet ds = new DataSet();
            string st = "No record found";

            PostResponse response = new PostResponse();
            try
            {

                SqlParameter prm1 = new SqlParameter("@Company_Id", request.Company_Id);
                SqlParameter prm2 = new SqlParameter("@Category_Description", request.Category_Description);



                using (con = new DBConnection())
                {
                    SqlParameter[] parameters = { prm1, prm2 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "CreateCategory", parameters);
                }

                response.Msg = "Success";
                response.Status = "true";

            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }
    }
}