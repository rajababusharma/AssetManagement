﻿using AssetManagementAPI.DatabaseHelper;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace AssetManagementAPI.BLL
{
    public class CreateCompanyBLL
    {
        DBConnection con;
        public PostResponse CreateCompany(CreateCompanyRequest users)
        {
            DataSet ds = new DataSet();
            string st = "No record found";

            PostResponse response = new PostResponse();
            try
            {

                SqlParameter prm1 = new SqlParameter("@Company_Id", users.Company_Id);
                SqlParameter prm2 = new SqlParameter("@User_Code", users.User_Code);
                SqlParameter prm3 = new SqlParameter("@User_Name", users.User_Name);
                SqlParameter prm4 = new SqlParameter("@Password", users.Password);
                SqlParameter prm5 = new SqlParameter("@IsActive", users.IsActive);
                SqlParameter prm6 = new SqlParameter("@Cdate", users.Cdate);
                SqlParameter prm7 = new SqlParameter("@Emp_Name", users.Emp_Name);

                SqlParameter prm8 = new SqlParameter("@Department", users.Department);
                SqlParameter prm9 = new SqlParameter("@Location", users.Location);
                SqlParameter prm10 = new SqlParameter("@Branch", users.Branch);
                SqlParameter prm11 = new SqlParameter("@Contact", users.Contact);
                SqlParameter prm12 = new SqlParameter("@EmailId", users.EmailId);
                SqlParameter prm13 = new SqlParameter("@pic", users.pic);

                SqlParameter prm14 = new SqlParameter("@Company_Name", users.Company_Name);
                SqlParameter prm15 = new SqlParameter("@Address1", users.Address1);
                SqlParameter prm16 = new SqlParameter("@Address2", users.Address2);
                SqlParameter prm17 = new SqlParameter("@ZipCode", users.ZipCode);
                SqlParameter prm18 = new SqlParameter("@gstno", users.gstno);

                using (con = new DBConnection())
                {
                    SqlParameter[] parameters = { prm1, prm2, prm3, prm4, prm5, prm6, prm7, prm8, prm9, prm10, prm11, prm12, prm13, prm14, prm15, prm16, prm17,prm18 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "CreateCompany", parameters);
                }




                response.Msg = "Success";
                response.Status = "true";


            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }

        public PostResponse IsCompanyExist()
        {
            DataSet ds = new DataSet();
            string st = "No record found";

            PostResponse response = new PostResponse();
            try
            {

               
               // SqlParameter prm1 = new SqlParameter("@ZipCode", users.ZipCode);


                using (con = new DBConnection())
                {
                   // SqlParameter[] parameters = { prm1 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "IfCompanyExist");
                }
                if (ds.Tables[0].Rows.Count > 0)
                {
                   
                   
                    
                    response.Msg = "Success";
                    response.Status = "true";

                }
                else
                {
                    response.Status = "false";
                    response.Msg = st;
                }



               


            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }
    }
}