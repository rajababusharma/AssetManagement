﻿using AssetManagementAPI.DatabaseHelper;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace AssetManagementAPI.BLL
{
    public class CreateAssetsBLL
    {
        DBConnection con;
        internal PostResponse CreateAssets(CreateAssetRequest request)
        {
            DataSet ds = new DataSet();
            string st = "No record found";

            PostResponse response = new PostResponse();
            try
            {

                SqlParameter prm1 = new SqlParameter("@Company_Id", request.Company_Id);
                SqlParameter prm2 = new SqlParameter("@Asset_id", request.Asset_id);
                SqlParameter prm3 = new SqlParameter("@FinancialYear", request.FinancialYear);
                SqlParameter prm4 = new SqlParameter("@Asset_name", request.Asset_name);
                SqlParameter prm5 = new SqlParameter("@Description", request.Description);
                SqlParameter prm6 = new SqlParameter("@Location", request.Location);
                SqlParameter prm7 = new SqlParameter("@Branch", request.Branch);
                SqlParameter prm8 = new SqlParameter("@Employee", request.Employee);
                SqlParameter prm9 = new SqlParameter("@Category", request.Category);
                SqlParameter prm10 = new SqlParameter("@SubCategory", request.SubCategory);
                SqlParameter prm11 = new SqlParameter("@Asset_type", request.Asset_type);
                SqlParameter prm12 = new SqlParameter("@Asset_value", request.Asset_value);
                SqlParameter prm13 = new SqlParameter("@Asset_life", request.Asset_life);
                SqlParameter prm14 = new SqlParameter("@Vendor", request.Vendor);
                SqlParameter prm15 = new SqlParameter("@SAP_code", request.SAP_code);
                SqlParameter prm16 = new SqlParameter("@Purchase_date", request.Purchase_date);
                SqlParameter prm17 = new SqlParameter("@Install_date", request.Install_date);
                SqlParameter prm18 = new SqlParameter("@ManufacturedBy", request.ManufacturedBy);
                SqlParameter prm19 = new SqlParameter("@Mfd_date", request.Mfd_date);
                SqlParameter prm20 = new SqlParameter("@Warranty_period", request.Warranty_period);
                SqlParameter prm21 = new SqlParameter("@Model_no", request.Model_no);
                SqlParameter prm22 = new SqlParameter("@Part_no", request.Part_no);
                SqlParameter prm23 = new SqlParameter("@Serial_no", request.Serial_no);
                SqlParameter prm24 = new SqlParameter("@Current_Date", request.Current_Date);
                SqlParameter prm25 = new SqlParameter("@Residual_value", request.Residual_value);
                SqlParameter prm26 = new SqlParameter("@Depreciation", request.Depreciation);
                SqlParameter prm27 = new SqlParameter("@Invoice_No", request.Invoice_No);
                SqlParameter prm28 = new SqlParameter("@Make", request.Make);
                SqlParameter prm29 = new SqlParameter("@Department", request.Department);
                SqlParameter prm30 = new SqlParameter("@Remark", request.Remark);
                SqlParameter prm31 = new SqlParameter("@FileName", request.FileName);


                using (con = new DBConnection())
                {
                    SqlParameter[] parameters = { prm1, prm2, prm3, prm4, prm5, prm6, prm7, prm8, prm9, prm10, prm11, prm12, prm13, prm14 , prm15, prm16, prm17, prm18, prm19, prm20, prm21, prm22, prm23, prm24, prm25, prm26, prm27, prm28, prm29, prm30, prm31 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "InsertIntoAssets", parameters);
                }




                response.Msg = "Success";
                response.Status = "true";


            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }

        internal Asset_InfoResponse GetStocks(string assetid,string branch)
        {
           
                DataSet ds = new DataSet();
                string st = "No record found";

            Asset_InfoResponse response = new Asset_InfoResponse();
                try
                {

                    SqlParameter prm1 = new SqlParameter("@Assetid", assetid);
                    SqlParameter prm2 = new SqlParameter("@Branchid", branch);


                using (con = new DBConnection())
                    {
                        SqlParameter[] parameters = { prm1,prm2 };
                        ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "GetAssetInfo", parameters);
                    }


                   
                    if (ds.Tables[0].Rows.Count > 0)
                    {

                    CreateAssetRequest stockDetails = new CreateAssetRequest();
                            stockDetails.Company_Id = ds.Tables[0].Rows[0]["Company_Id"].ToString();
                            stockDetails.Asset_id = ds.Tables[0].Rows[0]["Asset_id"].ToString();
                            stockDetails.Asset_name = ds.Tables[0].Rows[0]["Asset_name"].ToString();
                            stockDetails.Description = ds.Tables[0].Rows[0]["Description"].ToString();
                            stockDetails.Branch = ds.Tables[0].Rows[0]["Branch"].ToString();
                            stockDetails.Employee = ds.Tables[0].Rows[0]["Employee"].ToString();
                            stockDetails.Location = ds.Tables[0].Rows[0]["Location"].ToString();

                            stockDetails.Category = ds.Tables[0].Rows[0]["Category"].ToString();
                            stockDetails.SubCategory = ds.Tables[0].Rows[0]["SubCategory"].ToString();

                            stockDetails.Asset_type = ds.Tables[0].Rows[0]["Asset_type"].ToString();
                            stockDetails.Asset_value = ds.Tables[0].Rows[0]["Asset_value"].ToString();
                            stockDetails.Asset_life =Convert.ToInt32(ds.Tables[0].Rows[0]["Asset_life"]);

                            stockDetails.Vendor = ds.Tables[0].Rows[0]["Vendor"].ToString();
                            stockDetails.SAP_code = ds.Tables[0].Rows[0]["SAP_code"].ToString();

                            stockDetails.Purchase_date = ds.Tables[0].Rows[0]["Purchase_date"].ToString();
                            stockDetails.Install_date = ds.Tables[0].Rows[0]["Install_date"].ToString();
                            stockDetails.ManufacturedBy = ds.Tables[0].Rows[0]["ManufacturedBy"].ToString();
                            stockDetails.Mfd_date = ds.Tables[0].Rows[0]["Mfd_date"].ToString();

                            stockDetails.Warranty_period = ds.Tables[0].Rows[0]["Warranty_period"].ToString();
                            stockDetails.Model_no = ds.Tables[0].Rows[0]["Model_no"].ToString();
                            stockDetails.Part_no = ds.Tables[0].Rows[0]["Part_no"].ToString();

                            stockDetails.Serial_no = ds.Tables[0].Rows[0]["Serial_no"].ToString();
                            stockDetails.Current_Date = ds.Tables[0].Rows[0]["Current_Date"].ToString();
                            stockDetails.Residual_value = ds.Tables[0].Rows[0]["Residual_value"].ToString();
                            stockDetails.Depreciation = ds.Tables[0].Rows[0]["Depreciation"].ToString();
                            stockDetails.Invoice_No = ds.Tables[0].Rows[0]["Invoice_No"].ToString();
                            stockDetails.Make = ds.Tables[0].Rows[0]["Make"].ToString();
                            stockDetails.Department = ds.Tables[0].Rows[0]["Department"].ToString();
                    stockDetails.Remark = ds.Tables[0].Rows[0]["Remark"].ToString();
                    stockDetails.FileName = ds.Tables[0].Rows[0]["FileName"].ToString();



                    response.Assets = stockDetails;
                        response.Msg = "Success";
                        response.Status = "true";

                    }
                    else
                    {
                        response.Status = "false";
                        response.Msg = st;
                    }
                }
                catch (Exception ex)
                {
                    st = ex.Message;
                    response.Msg = st;
                    response.Status = "false";

                }

                return response;
            
        }

        internal AssetDataResponse GetStocks(string branch)
        {

            DataSet ds = new DataSet();
            string st = "No record found";

            AssetDataResponse response = new AssetDataResponse();
            try
            {
                SqlParameter prm1 = new SqlParameter("@Branchid", branch);


                using (con = new DBConnection())
                {
                    SqlParameter[] parameters = { prm1 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "GetAssetData", parameters);
                }


                List<CreateAssetRequest> Assets = new List<CreateAssetRequest>();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                    {
                       
                        CreateAssetRequest stockDetails = new CreateAssetRequest();
                        stockDetails.Company_Id = ds.Tables[0].Rows[0]["Company_Id"].ToString();
                        stockDetails.Asset_id = ds.Tables[0].Rows[0]["Asset_id"].ToString();
                        stockDetails.Asset_name = ds.Tables[0].Rows[0]["Asset_name"].ToString();
                        stockDetails.Description = ds.Tables[0].Rows[0]["Description"].ToString();
                        stockDetails.Branch = ds.Tables[0].Rows[0]["Branch"].ToString();
                        stockDetails.Employee = ds.Tables[0].Rows[0]["Employee"].ToString();
                        stockDetails.Location = ds.Tables[0].Rows[0]["Location"].ToString();

                        stockDetails.Category = ds.Tables[0].Rows[0]["Category"].ToString();
                        stockDetails.SubCategory = ds.Tables[0].Rows[0]["SubCategory"].ToString();

                        stockDetails.Asset_type = ds.Tables[0].Rows[0]["Asset_type"].ToString();
                        stockDetails.Asset_value = ds.Tables[0].Rows[0]["Asset_value"].ToString();
                        stockDetails.Asset_life = Convert.ToInt32(ds.Tables[0].Rows[0]["Asset_life"]);

                        stockDetails.Vendor = ds.Tables[0].Rows[0]["Vendor"].ToString();
                        stockDetails.SAP_code = ds.Tables[0].Rows[0]["SAP_code"].ToString();

                        stockDetails.Purchase_date = ds.Tables[0].Rows[0]["Purchase_date"].ToString();
                        stockDetails.Install_date = ds.Tables[0].Rows[0]["Install_date"].ToString();
                        stockDetails.ManufacturedBy = ds.Tables[0].Rows[0]["ManufacturedBy"].ToString();
                        stockDetails.Mfd_date = ds.Tables[0].Rows[0]["Mfd_date"].ToString();

                        stockDetails.Warranty_period = ds.Tables[0].Rows[0]["Warranty_period"].ToString();
                        stockDetails.Model_no = ds.Tables[0].Rows[0]["Model_no"].ToString();
                        stockDetails.Part_no = ds.Tables[0].Rows[0]["Part_no"].ToString();

                        stockDetails.Serial_no = ds.Tables[0].Rows[0]["Serial_no"].ToString();
                        stockDetails.Current_Date = ds.Tables[0].Rows[0]["Current_Date"].ToString();
                        stockDetails.Residual_value = ds.Tables[0].Rows[0]["Residual_value"].ToString();
                        stockDetails.Depreciation = ds.Tables[0].Rows[0]["Depreciation"].ToString();
                        stockDetails.Invoice_No = ds.Tables[0].Rows[0]["Invoice_No"].ToString();
                        stockDetails.Make = ds.Tables[0].Rows[0]["Make"].ToString();
                        stockDetails.Department = ds.Tables[0].Rows[0]["Department"].ToString();
                        stockDetails.Remark = ds.Tables[0].Rows[0]["Remark"].ToString();
                        stockDetails.FileName = ds.Tables[0].Rows[0]["FileName"].ToString();
                        Assets.Add( stockDetails );

                    }
                    response.Assets = Assets;
                    response.Msg = "Success";
                    response.Status = "true";

                }
                else
                {
                    response.Status = "false";
                    response.Msg = st;
                }
            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;

        }
    }
}