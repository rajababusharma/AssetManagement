﻿using AssetManagementAPI.DatabaseHelper;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Http;

namespace AssetManagementAPI.BLL
{
    public class GetStockTallyBLL
    {
        DBConnection con;
        public StockTallyGetResponse GetStockTally(string Branch)
        {
            DataSet ds = new DataSet();
            string st = "No record found";

            StockTallyGetResponse response = new StockTallyGetResponse();
            try
            {

                SqlParameter prm1 = new SqlParameter("@Branch", Branch);
               

                using (con = new DBConnection())
                {
                    SqlParameter[] parameters = { prm1 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "ast_mobile_GetStockTallyDetails", parameters);
                }


                List<STockTallyDetails> stockDetailslist = new List<STockTallyDetails>();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                    {
                        STockTallyDetails stockDetails = new STockTallyDetails();
                        stockDetails.Company_Id = ds.Tables[0].Rows[i]["Company_Id"].ToString();
                        stockDetails.Asset_id = ds.Tables[0].Rows[i]["Asset_id"].ToString();
                        stockDetails.Asset_name = ds.Tables[0].Rows[i]["Asset_name"].ToString();
                        stockDetails.Description = ds.Tables[0].Rows[i]["Description"].ToString();
                        stockDetails.Branch = ds.Tables[0].Rows[i]["Branch"].ToString();
                        stockDetails.Employee = ds.Tables[0].Rows[i]["Employee"].ToString();
                        stockDetails.Location = ds.Tables[0].Rows[i]["Location"].ToString();
                        stockDetailslist.Add(stockDetails);
                       
                    }
                    response.STockTallyDetails = stockDetailslist;
                    response.Msg = "Success";
                    response.Status = "true";

                }
                else
                {
                    response.Status = "false";
                    response.Msg = st;
                }
            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }

        public StockTallyGetResponse GetFoundMissing(string branch)
        {
            DataSet ds = new DataSet();
            string st = "No record found";

            StockTallyGetResponse response = new StockTallyGetResponse();
            try
            {

                SqlParameter prm1 = new SqlParameter("@branch", branch);


                using (con = new DBConnection())
                {
                    SqlParameter[] parameters = { prm1 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "GetAssetsFoundMissingReport", parameters);
                }


                List<STockTallyDetails> stockDetailslist = new List<STockTallyDetails>();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                    {
                        STockTallyDetails stockDetails = new STockTallyDetails();
                        stockDetails.Company_Id = ds.Tables[0].Rows[i]["Company_Id"].ToString();
                        stockDetails.Asset_id = ds.Tables[0].Rows[i]["Asset_id"].ToString();
                        stockDetails.Asset_name = ds.Tables[0].Rows[i]["Asset_name"].ToString();
                        stockDetails.Description = ds.Tables[0].Rows[i]["Description"].ToString();
                        stockDetails.Branch = ds.Tables[0].Rows[i]["Branch"].ToString();
                        stockDetails.Employee = ds.Tables[0].Rows[i]["Employee"].ToString();
                        stockDetails.Location = ds.Tables[0].Rows[i]["Location"].ToString();
                        stockDetails.sDate =Convert.ToDateTime(ds.Tables[0].Rows[i]["sDate"]);
                        stockDetails.User_Name = ds.Tables[0].Rows[i]["User_Name"].ToString();
                        stockDetails.Status = ds.Tables[0].Rows[i]["Status"].ToString();
                        stockDetailslist.Add(stockDetails);

                    }
                    response.STockTallyDetails = stockDetailslist;
                    response.Msg = "Success";
                    response.Status = "true";

                }
                else
                {
                    response.Status = "false";
                    response.Msg = st;
                }
            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }

        private DataTable createDetailListDataTable()
        {
            DataTable dt = new DataTable();

            dt.Columns.Add("Company_Id", typeof(string));
            dt.Columns.Add("Asset_id", typeof(string));
            dt.Columns.Add("Asset_name", typeof(string));
            dt.Columns.Add("Description", typeof(string));
            dt.Columns.Add("Location", typeof(string));
            dt.Columns.Add("Branch", typeof(string));
            dt.Columns.Add("Employee", typeof(string));
            dt.Columns.Add("sDate", typeof(DateTime));
            dt.Columns.Add("Status", typeof(string));
            dt.Columns.Add("User_Name", typeof(string));
            return dt;
        }

            public PostResponse PostStockTally(List<STockTallyDetails> STockTallyDetails)
            {
            DateTime timeStamp = DateTime.Today;

            DataSet ds = new DataSet();
            string st = "";
            DataSet dsPLs = new DataSet();
            DataTable dt = new DataTable();
            dt = createDetailListDataTable();
            PostResponse response = new PostResponse();
            try
            {
                string branch = "";
               
                for (int i = 0; i <= STockTallyDetails.Count - 1; i++)
                {
                    int srno = 1;
                    DataRow dr = dt.NewRow();
                    dr["Company_Id"] = STockTallyDetails[i].Company_Id;
                    dr["Asset_id"] = STockTallyDetails[i].Asset_id;
                    //dr["Docket_Date"] = Convert.ToString(PDSAddEntity.pDSAddDetails[i].Do);
                    dr["Asset_name"] = STockTallyDetails[i].Asset_name;
                    dr["Description"] = STockTallyDetails[i].Description;
                    dr["Location"] = STockTallyDetails[i].Location;
                    dr["Branch"] = STockTallyDetails[i].Branch;
                    branch= STockTallyDetails[i].Branch;
                    dr["Employee"] = STockTallyDetails[i].Employee;
                     dr["sDate"] = timeStamp;
                    dr["Status"] = STockTallyDetails[i].Status;
                    dr["User_Name"] = STockTallyDetails[i].User_Name;
                    dt.Rows.Add(dr);
                    srno++;
                }
                SqlParameter prm_branch = new SqlParameter("@branch", branch);
                dsPLs.Tables.Add(dt);
                dsPLs.Tables[0].TableName = "stocktally_data";
                SqlParameter prm1 = new SqlParameter("@stockTakexml", dsPLs.GetXml());
                using (con = new DBConnection())
                {
                    SqlParameter[] parameters = { prm_branch };
                    SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "ClearStockInventory", prm_branch);
                }
                using (con = new DBConnection())
                {
                    SqlParameter[] parameters = { prm1};
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "ast_mobile_StockTally_Add", parameters);
                }

               
                        response.Msg = "Success";
               
                    response.Status = "true";
               
            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";
               
            }

            return response;
        }

        public void ClearStockTally(string Branch)
        {
            DataSet ds = new DataSet();
            string st = "No record found";

           // StockTallyGetResponse response = new StockTallyGetResponse();
            try
            {

                SqlParameter prm1 = new SqlParameter("@Branch", Branch);


                using (con = new DBConnection())
                {
                    SqlParameter[] parameters = { prm1 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "ClearStockInventory", parameters);
                }
            }
            catch (Exception ex)
            {
              

            }

           
        }
    }
}