﻿using AssetManagementAPI.DatabaseHelper;
using AssetManagementAPI.Models;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace AssetManagementAPI.BLL
{
    public class LocationMasterBLL
    {
        DBConnection con;
        public LocationMasterResp GetALLLocations()
        {
            DataSet ds = new DataSet();
            string st = "No record found";

            LocationMasterResp response = new LocationMasterResp();
            try
            {

                // SqlParameter prm1 = new SqlParameter("@Branch", Branch);


                using (con = new DBConnection())
                {
                    // SqlParameter[] parameters = { prm1 };
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "GetLocationList");
                }


                List<string> locationlist = new List<string>();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    for (int i = 0; i <= ds.Tables[0].Rows.Count - 1; i++)
                    {



                        locationlist.Add(ds.Tables[0].Rows[i]["Location_Description"].ToString());

                    }
                    response.Locations = locationlist;
                    response.Msg = "Success";
                    response.Status = "true";

                }
                else
                {
                    response.Status = "false";
                    response.Msg = st;
                }
            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }

        public PostResponse CreateLocations(CreateLocationRequest request)
        {
            DataSet ds = new DataSet();
            string st = "No record found";

            PostResponse response = new PostResponse();
            try
            {

                SqlParameter prm1 = new SqlParameter("@Company_Id", request.Company_Id);
                SqlParameter prm2 = new SqlParameter("@Location_Description", request.Location_Description);
               


                using (con = new DBConnection())
                {
                    SqlParameter[] parameters = { prm1, prm2};
                    ds = SqlHelper.ExecuteDataset(con.connection, CommandType.StoredProcedure, "CreateLocation", parameters);
                }

                response.Msg = "Success";
                response.Status = "true";

            }
            catch (Exception ex)
            {
                st = ex.Message;
                response.Msg = st;
                response.Status = "false";

            }

            return response;
        }
    }
}