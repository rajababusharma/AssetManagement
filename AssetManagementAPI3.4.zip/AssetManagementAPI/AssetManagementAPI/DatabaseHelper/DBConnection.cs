﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace AssetManagementAPI.DatabaseHelper
{
    public class DBConnection : IDisposable
    {
        public static string connectionString;
        SqlConnection con;


        public DBConnection()
        {
            //Taking Connections
            connectionString = ConfigurationManager.ConnectionStrings["DbConnectionString"].ToString();
            //connectionString2 = ConfigurationManager.ConnectionStrings["DbConnectionString2"].ToString();

            //Initialising Connections
            con = new SqlConnection(connectionString);
            //  con2 = new SqlConnection(connectionString2);


        }
        public SqlConnection connection { get { return con; } }
        // public SqlConnection connection2 { get { return con2; } }

        public void Dispose()
        {
            //Closing Connections 
            if (connection.State == ConnectionState.Open)
            {
                connection.Close();
                connection.Dispose();

            }


        }
    }
}